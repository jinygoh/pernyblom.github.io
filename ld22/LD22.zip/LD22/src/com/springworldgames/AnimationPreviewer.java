package com.springworldgames;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class AnimationPreviewer extends JFrame {

	public AnimationPanel panel;

	private class AnimationPanel extends JPanel {

		public int currentFrame = 0;

		private BufferedImage image;

		
		public AnimationPanel() throws Exception {
			String filename = "C:\\Users\\Per\\Documents\\Javascriptprojekt\\animations.png";
			image = ImageIO.read(new File(filename));
		}

		public void paintPlayerAnimation(Graphics g, int frame, int index) {
			if (image != null) {
//				g.drawImage(image, 0, 0, null);
				int scaleup = 3;
				g.drawImage(image, // 
						index * 32 * scaleup, // dx1 
						0, // dy1
						(index + 1) * 32 * scaleup, // dx2 
						64 * scaleup, // dy2
						frame * 32, // sx1
						(index) * 64, // sx1
						(frame + 1) * 32, // sx2
						(index + 1) * 64, // sy2
						Color.white, null);
//				System.out.println(this);
			}
		}

		@Override
		public void paint(Graphics g) {
			super.paint(g);
//			paintPlayerAnimation(g, currentFrame, 0);
//			paintPlayerAnimation(g, currentFrame, 1);
			paintPlayerAnimation(g, currentFrame, 2);
//			paintPlayerAnimation(g, currentFrame, 3);
//			paintPlayerAnimation(g, currentFrame, 4);
//			paintPlayerAnimation(g, currentFrame, 5);
		}
	}

	public AnimationPreviewer() throws Exception {
		super("Animiations");

		this.panel = new AnimationPanel();
		panel.setPreferredSize(new Dimension(1024, 768));

		add(panel);

		setSize(1024, 768);
	}

	static AnimationPreviewer previewer;

	
	public static void main(String[] args) throws Exception {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				try {
					previewer = new AnimationPreviewer();
					previewer.setDefaultCloseOperation(EXIT_ON_CLOSE);
					previewer.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		while (true) {
			Thread.sleep(100);
			if (previewer != null && previewer.panel != null) {
				previewer.panel.repaint();
				previewer.panel.currentFrame = (previewer.panel.currentFrame + 1) % 6;
				 
//				System.out.println(previewer.panel.currentFrame);
			}
		}

	}

}
