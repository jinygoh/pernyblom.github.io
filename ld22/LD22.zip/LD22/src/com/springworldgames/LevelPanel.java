package com.springworldgames;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;

import javax.swing.JPanel;

import com.springworldgames.LevelEditor.EditMode;

public class LevelPanel extends JPanel implements MouseListener,
		MouseMotionListener {

	Level level;

	LinkedList<Level> levelHistory = new LinkedList<Level>();
	long lastLevelHistoryMillis = -1;

	int tileSize = 32;

	Point overCell = null;

	private LevelEditor editor;

	public LevelPanel(Level l, LevelEditor editor) {
		this.level = l;
		this.editor = editor;

		int pw = level.getWidth() * tileSize;
		int ph = level.getHeight() * tileSize;

		setPreferredSize(new Dimension(pw, ph));
		setMinimumSize(new Dimension(pw, ph));
		setMaximumSize(new Dimension(pw, ph));

		addMouseListener(this);
		addMouseMotionListener(this);
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);

		g.setColor(Color.white);
		g.fillRect(0, 0, getWidth(), getHeight());

		// Paint background grid
		g.setColor(Color.black);
		for (int i = 0; i < level.getWidth() + 1; i++) {
			g.drawLine(i * tileSize, 0, i * tileSize, level.getHeight()
					* tileSize);
		}
		for (int j = 0; j < level.getHeight() + 1; j++) {
			g.drawLine(0, j * tileSize, level.getWidth() * tileSize, j
					* tileSize);
		}

		// Paint the background tiles
		String[][] backgroundTiles = level.getBackgroundTiles();
		for (int i = 0; i < backgroundTiles.length; i++) {
			for (int j = 0; j < backgroundTiles[i].length; j++) {
				Color fillColor = null;
				String tileString = backgroundTiles[i][j];
				BackgroundTilesEditMode mode = BackgroundTilesEditMode
						.getFromString(tileString);

				if (mode != null) {
					fillColor = mode.getColor();
				}
				if (fillColor != null) {
					g.setColor(fillColor);
					g.fillRect(i * tileSize, j * tileSize, tileSize, tileSize);
				}
			}
		}

		// Paint surface tiles
		String[][] surfaceTiles = level.getSurfaceTiles();
		for (int i = 0; i < surfaceTiles.length; i++) {
			for (int j = 0; j < surfaceTiles[i].length; j++) {
				Color fillColor = null;
				String tileString = surfaceTiles[i][j];
				SurfaceTilesEditMode mode = SurfaceTilesEditMode
						.getFromString(tileString);

				if (mode != null) {
					fillColor = mode.getColor();
				}
				if (fillColor != null) {
					g.setColor(fillColor);
					g.fillRect(i * tileSize, j * tileSize, tileSize, tileSize);
				}
			}
		}

		// Paint objects
		LinkedHashMap<String, Object>[][] objectsData = level.getObjectsData();

		for (int i = 0; i < objectsData.length; i++) {
			for (int j = 0; j < objectsData[i].length; j++) {
				LinkedHashMap<String, Object> map = objectsData[i][j];

				if (map == null) {
					continue;
				}
				String symbol = (String) map.get("symbol");

				ObjectsEditMode mode = ObjectsEditMode.getFromString(symbol);

				String fillString = null;
				if (mode != null && mode != ObjectsEditMode.NONE) {
					fillString = mode.getShortString();
				}
				if (fillString != null) {
					g.setColor(Color.black);
					g.drawString(fillString, i * tileSize + 1, j * tileSize
							+ 11);
					g.setColor(Color.white);
					g.drawString(fillString, i * tileSize, j * tileSize + 10);
				}
			}
		}

		// Paint decorations
		String[][] decorations = level.getDecorations();
		for (int i = 0; i < decorations.length; i++) {
			for (int j = 0; j < decorations[i].length; j++) {
				String tileString = decorations[i][j];
				DecorationsEditMode mode = DecorationsEditMode
						.getFromString(tileString);

				String fillString = null;
				if (mode != null && mode != DecorationsEditMode.NONE) {
					fillString = mode.getShortString();
				}
				if (fillString != null) {
					g.setColor(Color.black);
					g.drawString(fillString, i * tileSize + 1, j * tileSize
							+ 26);
					g.setColor(Color.green);
					g.drawString(fillString, i * tileSize, j * tileSize + 25);
				}
			}
		}

		if (overCell != null) {
			g.setColor(Color.yellow);
			int rectWidth = 1;
			int rectHeight = 1;
			switch (editor.currentEditMode) {
			case OBJECTS:
				rectWidth = editor.currentObjectsEditMode.getWidth();
				rectHeight = editor.currentObjectsEditMode.getHeight();
				break;
			}
			g.drawRect(overCell.x * tileSize, overCell.y * tileSize, tileSize
					* rectWidth, tileSize * rectHeight);
		}
	}

	public Level getLevel() {
		return level;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	void paintHere(int mx, int my) {
		addToHistoryIfNecessary();

		int pressCellX = mx / 32;
		int pressCellY = my / 32;

		boolean validPressCell = pressCellX >= 0
				&& pressCellX < level.getWidth() && pressCellY >= 0
				&& pressCellY < level.getHeight();

		String[][] arrToSet = null;
		LinkedHashMap<String, Object>[][] dataArrToSet = null;
		String cellString = null;
		LinkedHashMap<String, Object> defaultProperties = null;

		switch (editor.currentEditMode) {
		case BACKGROUND_TILES:
			arrToSet = level.getBackgroundTiles();
			cellString = editor.currentBackgroundTilesEditMode.getString();
			break;
		case DECORATIONS:
			arrToSet = level.getDecorations();
			cellString = editor.currentDecorationsEditMode.getString();
			break;
		case OBJECTS:
			dataArrToSet = level.getObjectsData();
			cellString = editor.currentObjectsEditMode.getString();
			defaultProperties = editor.currentObjectsEditMode
					.getNewDefaultProperties();
			System.out.println(this.getClass().getSimpleName()
					+ " default properties: " + defaultProperties);
			break;
		case SURFACE_TILES:
			arrToSet = level.getSurfaceTiles();
			cellString = editor.currentSurfaceTilesEditMode.getString();
			break;
		case OBJECT_PROPERTIES:
			// This is not a paint
			if (validPressCell) {
				LinkedHashMap<String, Object>[][] objectsData = level
						.getObjectsData();
				editor
						.updatePropertiesPanel(objectsData[pressCellX][pressCellY]);
			}
			break;
		}

		int rectWidth = 1;
		int rectHeight = 1;
		switch (editor.currentEditMode) {
		case OBJECTS:
			rectWidth = editor.currentObjectsEditMode.getWidth();
			rectHeight = editor.currentObjectsEditMode.getHeight();
			break;
		}

		if (cellString != null && validPressCell) {
			switch (editor.currentPaintMode) {
			case FILL_ALL:
				if (editor.currentEditMode != EditMode.OBJECTS) {
					for (int i = 0; i < arrToSet.length; i++) {
						for (int j = 0; j < arrToSet[i].length; j++) {
							arrToSet[i][j] = cellString;
						}
					}
				}
				break;
			case PENCIL:
				for (int i = 0; i < rectWidth; i++) {
					for (int j = 0; j < rectHeight; j++) {
						if (arrToSet != null) {
							String old = arrToSet[pressCellX + i][pressCellY
									+ j];
							if (!old.equals(cellString)) {
								arrToSet[pressCellX + i][pressCellY + j] = cellString;
							}
						}
						if (dataArrToSet != null) {
							LinkedHashMap<String, Object> old = dataArrToSet[pressCellX
									+ i][pressCellY + j];
							if (old == null
									|| defaultProperties == null
									|| !old.get("symbol").equals(
											defaultProperties.get("symbol"))) {
								dataArrToSet[pressCellX + i][pressCellY + j] = defaultProperties;
								if (defaultProperties != null) {
									defaultProperties.put("x", pressCellX + i);
									defaultProperties.put("y", pressCellY + j);
								}
							}
						}
					}
				}
				break;
			case FILL_REGION:
				if (editor.currentEditMode != EditMode.OBJECTS) {
					fillRegion(pressCellX, pressCellY, cellString, arrToSet);
				}
				break;
			}
			// System.out.println("level panel setting " + pressCellX + " "
			// + pressCellY + " to " + cellString);
		}
		repaint();
	}

	private void fillRegion(int cellX, int cellY, String cellString,
			String[][] arrToSet) {
		String startString = arrToSet[cellX][cellY];

		LinkedList<int[]> fringe = new LinkedList<int[]>();

		fringe.add(new int[] { cellX, cellY });

		LinkedHashSet<String> visited = new LinkedHashSet<String>();

		while (!fringe.isEmpty()) {
			int[] coords = fringe.removeLast();
			int x = coords[0];
			int y = coords[1];
			visited.add(x + "," + y);
			String str = arrToSet[x][y];
			if (str.equals(startString)) {
				// Expand and set
				arrToSet[x][y] = cellString;
				int leftX = x - 1;
				int rightX = x + 1;
				int upY = y - 1;
				int downY = y + 1;

				if (leftX >= 0 && !fringe.contains(leftX + "," + y)) {
					fringe.add(new int[] { leftX, y });
				}
				if (rightX < arrToSet.length
						&& !fringe.contains(rightX + "," + y)) {
					fringe.add(new int[] { rightX, y });
				}
				if (upY >= 0 && !fringe.contains(x + "," + upY)) {
					fringe.add(new int[] { x, upY });
				}
				if (downY < arrToSet[0].length
						&& !fringe.contains(x + "," + downY)) {
					fringe.add(new int[] { x, downY });
				}
			}
		}

	}

	@Override
	public void mousePressed(MouseEvent e) {
		paintHere(e.getX(), e.getY());
	}

	void addToHistoryIfNecessary() {
		boolean add = false;
		if (lastLevelHistoryMillis == -1) {
			lastLevelHistoryMillis = System.currentTimeMillis();
			add = true;
		}
		if (levelHistory.size() > 0) {
			Level theLast = levelHistory.getLast();
			if (level.equals(theLast)) {
				System.out.println("not adding identical in level panel");
				return;
			}
		}

		long currentMillis = System.currentTimeMillis();
		if (currentMillis - lastLevelHistoryMillis > 1000) {
			add = true;
		}
		if (add) {
			levelHistory.add(level.copy());
			lastLevelHistoryMillis = currentMillis;
		}
	}

	public void undo() {
		if (levelHistory.size() > 0) {
			Level last = levelHistory.removeLast();
			level = last.copy();
			repaint();
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		moveToHere(e.getX(), e.getY());
		paintHere(e.getX(), e.getY());
	}

	void moveToHere(int mx, int my) {
		// System.out.println("levelpanel x: " + e.getX() + " y: " +
		// e.getY());
		int overCellX = mx / 32;
		int overCellY = my / 32;

		overCell = new Point(overCellX, overCellY);
		repaint();
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		int mx = e.getX();
		int my = e.getY();
		moveToHere(mx, my);
	}

}
