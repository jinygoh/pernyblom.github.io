package com.springworldgames;

import java.awt.Color;
import java.util.LinkedHashMap;

import com.springworldgames.LevelEditor.EditModeInterface;

public enum BackgroundTilesEditMode implements EditModeInterface {
	NONE(".", "None", Color.black), ROCK("r", "Rock", Color.gray);

	private String string;
	private String guiName;
	private Color color;

	private static LinkedHashMap<String, BackgroundTilesEditMode> stringToModeMap;

	private BackgroundTilesEditMode(String string, String guiName, Color color) {
		this.string = string;
		this.guiName = guiName;
		this.color = color;
	}

	public Color getColor() {
		return color;
	}

	public String getString() {
		return string;
	}

	public String getGuiName() {
		return guiName;
	}

	public static BackgroundTilesEditMode getFromString(String tileString) {
		if (stringToModeMap == null) {
			stringToModeMap = new LinkedHashMap<String, BackgroundTilesEditMode>();
			for (BackgroundTilesEditMode mode : values()) {
				stringToModeMap.put(mode.getString(), mode);
			}
		}
		return stringToModeMap.get(tileString);
	}

}
