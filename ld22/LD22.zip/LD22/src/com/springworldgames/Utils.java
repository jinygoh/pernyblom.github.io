package com.springworldgames;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.imageio.ImageIO;

public class Utils {

	static String dir = "C:\\Users\\Per\\Programmeringsprojekt\\LD22\\DevResources\\game\\";

	public static Set<String> getPossibleSymbols() {
		String longString = "abcdefghijklmnopqrstuvwxyABCDEFGHIJKLMNOPQRSTUVWXY1234567890!#%&/()=?'*-_.:,;<>";
		LinkedHashSet<String> symbols = new LinkedHashSet<String>();
		for (int i = 0; i < longString.length(); i++) {
			symbols.add("" + longString.charAt(i));
		}
		return symbols;
	}

	public static void executeFfmpeg(String ffmpegPath, String arguments) {
		try {
			String string = ffmpegPath + " " + arguments;

			Process process = Runtime.getRuntime().exec(string);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void convertFileToMp3(String ffmpegPath, File sourceFile,
			File targetFile) {
		executeFfmpeg(ffmpegPath, "-y -i \"" + sourceFile.getAbsolutePath()
				+ "\" -acodec libmp3lame -ab 192k \""
				+ targetFile.getAbsolutePath() + "\"");
	}

	public static void convertFileToOggVorbis(String ffmpegPath,
			File sourceFile, File targetFile) {

		// ffmpeg -i audio.wav -acodec vorbis -aq 60 audio.ogg
		executeFfmpeg(ffmpegPath, "-y -i \"" + sourceFile.getAbsolutePath()
				+ "\" -acodec libvorbis -aq 60 \""
				+ targetFile.getAbsolutePath() + "\"");
	}

	static void convertSoundEffects() {
		String ffmpegPath = "C:\\Users\\Per\\Programmeringsprojekt\\Libs\\FFMPEG\\ffmpeg.exe";

		String[] soundFiles = { "blip_1", "button_press_1", "charge", "hit_1",
				"release", "try_hit", "star_pickup", "health_pickup", "happy_music" };

		for (String soundFile : soundFiles) {
			File sourceFile = new File(dir + soundFile + ".wav");
			File targetFile = new File(dir + soundFile + ".mp3");
			convertFileToMp3(ffmpegPath, sourceFile, targetFile);
		}

	}

	static class CopyInfo {
		private int steps = 12;
		private int xStepLength = 32;
		private int yStepLength = 48;
		private int sourceX = 0;
		private int sourceY = 16;
		private int targetX = 0;
		private int targetY = 240;
		private int[][] replacements;

		public CopyInfo(int steps, int xStepLength, int yStepLength,
				int sourceX, int sourceY, int targetX, int targetY,
				int[][] replacements) {
			super();
			this.steps = steps;
			this.xStepLength = xStepLength;
			this.yStepLength = yStepLength;
			this.sourceX = sourceX;
			this.sourceY = sourceY;
			this.targetX = targetX;
			this.targetY = targetY;
			this.replacements = replacements;
		}

	}

	// Can be used to make several copies of images
	static void createFullImage() throws Exception {

		BufferedImage sourceImage = ImageIO.read(new File(dir
				+ "unprocessed.png"));

		int w = sourceImage.getWidth();
		int h = sourceImage.getHeight();

		int[] rgbArray = sourceImage.getRGB(0, 0, sourceImage.getWidth(),
				sourceImage.getHeight(), null, 0, sourceImage.getWidth());

		// Color conversion
		int[][] grayToRed = new int[][] { //
		//
				{ 0xff007d00, 0xffff0000 }, //
				{ 0xff005300, 0xffc80000 }, //
				{ 0xff003e00, 0xffa20000 }, //
				{ 0xff002200, 0xff760000 }, //
		//
		};

		ArrayList<CopyInfo> copyInfos = new ArrayList<CopyInfo>();
		// Create light gray uniform
		copyInfos.add(new CopyInfo(12, 32, 96, 0, 16, 0, 240, grayToRed));

		for (CopyInfo copyInfo : copyInfos) {

			HashMap<Integer, Integer> colorReplacements = new HashMap<Integer, Integer>();
			for (int i = 0; i < copyInfo.replacements.length; i++) {
				int[] arr = copyInfo.replacements[i];
				colorReplacements.put(arr[0], arr[1]);
			}

			int steps = copyInfo.steps;
			int xStepLength = copyInfo.xStepLength;
			int yStepLength = copyInfo.yStepLength;
			int sourceX = copyInfo.sourceX;
			int sourceY = copyInfo.sourceY;
			int targetX = copyInfo.targetX;
			int targetY = copyInfo.targetY;

			for (int i = 0; i < steps; i++) {
				for (int j = 0; j < xStepLength; j++) {
					int sx = sourceX + i * xStepLength + j;
					int tx = targetX + i * xStepLength + j;
					for (int k = 0; k < yStepLength; k++) {
						int sy = k + sourceY;
						int ty = k + targetY;
						int sourceRgb = rgbArray[sx + sy * w];
						Integer replace = colorReplacements.get(sourceRgb);
						if (replace != null) {
							sourceRgb = replace;
						}
						rgbArray[tx + ty * w] = sourceRgb;
					}
				}
			}
		}
		sourceImage.setRGB(0, 0, sourceImage.getWidth(), sourceImage
				.getHeight(), rgbArray, 0, sourceImage.getWidth());

		ImageIO.write(sourceImage, "png", new File(dir + "processed.png"));
	}

	public static void main(String[] args) throws Exception {
		convertSoundEffects();
		// createFullImage();
	}
}
