package com.springworldgames;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import javax.imageio.ImageIO;

public class TimeLapse {

	public static String dir = "../Data/LD22Timelapse/";

	public static void runTimelapseCapture(int realSeconds, int fps,
			int videoLengthSeconds) throws Exception {

		int totalFrameCount = videoLengthSeconds * fps;

		double secondsBetweenEachTake = realSeconds
				/ (double) (totalFrameCount * fps);

		secondsBetweenEachTake = 15.0;
		
		System.out.println("Seconds between: " + secondsBetweenEachTake
				+ " Total frames: " + totalFrameCount);

		// double test = secondsBetweenEachTake * totalFrameCount;
		// System.out.println("Test: " + test);

		Robot robot = new Robot();
		int width = 1440;
		int height = 900;

		Font font = Font.createFont(Font.TRUETYPE_FONT, new File(
				"C:/Windows/Fonts/impact.ttf"));
		Font fontToUse = font.deriveFont((float) 20.0);

		while (true) {
			BufferedImage image = robot.createScreenCapture(new Rectangle(0, 0,
					width, height));

			Date date = new Date();
			String dateString = date.toString() + " (In Sweden)";

			Graphics2D g = image.createGraphics();
			FontMetrics fm = g.getFontMetrics(fontToUse);
			Rectangle2D bounds = fm.getStringBounds(dateString, g);

			int stringWidth = (int) bounds.getWidth();
			int x = width - 400;
			int y = 20;

			g.setColor(Color.lightGray);
			g.fillRect(x - 5, y - 20, stringWidth + 10, 30);

			g.setFont(fontToUse);
			g.setColor(Color.black);
			g.drawString(dateString, x, y);
			g.setColor(Color.white);
			g.drawString(dateString, x - 2, y - 2);

			ImageIO.write(image, "png", new File(dir + "tl_"
					+ System.currentTimeMillis() + ".png"));
			Thread.sleep((long) (secondsBetweenEachTake * 1000));
		}
	}

	public static void createTimelapseVideo(long fromMillis, long toMillis,
			int fps) throws Exception {

		// Gather all filenames that are within the time period and sort them
		ArrayList<String> filenames = new ArrayList<String>();

		File dirFile = new File(dir);
		File[] listFiles = dirFile.listFiles();
		for (File f : listFiles) {
			String filename = f.getName();
			if (filename.endsWith("png")) {
				filenames.add(filename);
			}
		}

		// Go through each file and add the image to the video stream

		File videoFile = new File(dir + "video_" + fromMillis + "_" + toMillis
				+ ".avi");
		AVIOutputStream videoOut = new AVIOutputStream(videoFile,
				AVIOutputStream.VideoFormat.JPG);
		videoOut.setFrameRate(fps);
		// videoOut.setVideoCompressionQuality((float) videoQuality);
		videoOut.setTimeScale(1);

		int imageWidth = -1;
		int imageHeight = -1;

		for (int i = 0; i < filenames.size(); i++) {
			String filename = filenames.get(i);
			File file = new File(dir + filename);
			try {
				BufferedImage image = ImageIO.read(file);
				if (imageWidth == -1) {
					imageWidth = image.getWidth();
				} else if (imageWidth != image.getWidth()) {
					System.out.println("Changed image width from " + imageWidth
							+ " to " + image.getWidth());
					imageWidth = image.getWidth();
				}
				if (imageHeight == -1) {
					imageHeight = image.getHeight();
				} else if (imageHeight != image.getHeight()) {
					System.out.println("Changed image height from "
							+ imageHeight + " to " + image.getHeight());
					imageHeight = image.getHeight();
				}
				videoOut.writeFrame(image);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("Writing " + i + " of " + filenames.size());
		}

		videoOut.close();

	}

	public static void main(String[] args) throws Exception {
		int realSeconds = 60 * 60 * 48;
		int fps = 10; // In the final video
		int videoLengthSeconds = 60 * 5; // Five minutes
		 runTimelapseCapture(realSeconds, fps, videoLengthSeconds);
//		createTimelapseVideo(0, Long.MAX_VALUE, fps);
	}

}
