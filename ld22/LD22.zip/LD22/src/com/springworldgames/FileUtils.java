package com.springworldgames;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.util.ArrayList;

public class FileUtils {

	public static File getNextFile(String prefix, String postfix) {
		int i = 1;
		while (true) {
			File f = new File(prefix + i + postfix);
			if (!f.exists()) {
				return f;
			}
			i++;
		}
	}

	public static void writeToFile(File file, String content) throws Exception {
		FileOutputStream fos = new FileOutputStream(file);
		fos.write(content.getBytes());
		fos.close();
	}

	public static String readFromTextFile(File file) throws Exception {
		StringBuilder contents = new StringBuilder();

		BufferedReader input = new BufferedReader(new FileReader(file));
		try {
			String line = null;
			while ((line = input.readLine()) != null) {
				contents.append(line);
				contents.append(System.getProperty("line.separator"));
			}
		} finally {
			input.close();
		}
		return contents.toString();
	}


	public static ArrayList<File> getAllFilesFilter(File dir,
			FilenameFilter filter) {
		File[] files = dir.listFiles(filter);
		ArrayList<File> result = new ArrayList<File>();

		if (files != null) {
			for (File f : files) {
				result.add(f);
			}
		}
		return result;
	}

	public static ArrayList<File> getAllFilesWithExtension(File dir,
			final String ext) {

		FilenameFilter filter = new FilenameFilter() {

			@Override
			public boolean accept(File f, String name) {
				return name.endsWith(ext);
			}
		};
		return getAllFilesFilter(dir, filter);
	}

	public static ArrayList<File> getAllFilesWithPrefixAndSuffix(File dir,
			final String prefix, final String suffix) {

		File[] files = dir.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File f, String name) {
				if (suffix == null) {
					return name.startsWith(prefix);
				} else if (prefix == null) {
					return name.startsWith(suffix);
				} else {
					return name.endsWith(suffix) && name.startsWith(prefix);
				}
			}

		});

		ArrayList<File> result = new ArrayList<File>();

		for (File f : files) {
			// System.out.println("Adding " + f.getName());
			result.add(f);
		}
		return result;
	}

}
