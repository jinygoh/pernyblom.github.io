package com.springworldgames;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

import org.w3c.dom.Element;

public class LevelEditor extends JFrame implements KeyListener {

	LinkedHashMap<Component, LevelPanel> tabComponentsLevelPanelMap = new LinkedHashMap<Component, LevelPanel>();

	private JPanel controlPanel;
	private JPanel propertiesPanel;

	public PaintMode currentPaintMode = PaintMode.PENCIL;

	String baseDir = "C:\\Users\\Per\\ProgrammeringsProjekt\\LD22\\DevResources\\game\\";

	String xmlSaveFile = baseDir + "levels.xml";
	String jsSaveFile = baseDir + "leveldata.js";
	String backupDir = baseDir + "backup";

	LinkedHashMap<EditMode, JRadioButton> modeButtonsMap = new LinkedHashMap<EditMode, JRadioButton>();
	LinkedHashMap<BackgroundTilesEditMode, JRadioButton> backgroundsButtonsMap = new LinkedHashMap<BackgroundTilesEditMode, JRadioButton>();
	LinkedHashMap<ObjectsEditMode, JRadioButton> objectsButtonsMap = new LinkedHashMap<ObjectsEditMode, JRadioButton>();
	LinkedHashMap<SurfaceTilesEditMode, JRadioButton> surfacesButtonsMap = new LinkedHashMap<SurfaceTilesEditMode, JRadioButton>();
	LinkedHashMap<DecorationsEditMode, JRadioButton> decorationsButtonsMap = new LinkedHashMap<DecorationsEditMode, JRadioButton>();

	public enum PaintMode {
		PENCIL("Pencil"), FILL_ALL("Fill All"), FILL_REGION("Fill Region");

		private String guiString;

		private PaintMode(String guiString) {
			this.guiString = guiString;
		}

		public String getGuiString() {
			return guiString;
		}
	}

	public EditMode currentEditMode;
	public BackgroundTilesEditMode currentBackgroundTilesEditMode;
	public SurfaceTilesEditMode currentSurfaceTilesEditMode;
	public ObjectsEditMode currentObjectsEditMode;
	public DecorationsEditMode currentDecorationsEditMode;

	private JPanel backgroundTilesPanel;

	private JTabbedPane tabbedPanel;

	@Override
	public void keyPressed(KeyEvent e) {
		int keyCode = e.getKeyCode();

		boolean altDown = e.isAltDown();
		boolean controlDown = e.isControlDown();
		boolean shiftDown = e.isShiftDown();

		JRadioButton button = null;

		if (!altDown && !controlDown && !shiftDown) {
			EditMode newMode = null;
			switch (keyCode) {
			case KeyEvent.VK_O:
				newMode = EditMode.OBJECTS;
				break;
			case KeyEvent.VK_P:
				newMode = EditMode.OBJECT_PROPERTIES;
				break;
			case KeyEvent.VK_D:
				newMode = EditMode.DECORATIONS;
				break;
			case KeyEvent.VK_B:
				newMode = EditMode.BACKGROUND_TILES;
				break;
			case KeyEvent.VK_S:
				newMode = EditMode.SURFACE_TILES;
				break;
			default:
				System.out.println(e);
				break;
			}
			if (newMode != null) {
				button = modeButtonsMap.get(newMode);
				currentEditMode = newMode;
			}
		}
		if (controlDown) {
			ObjectsEditMode newMode = null;
			switch (keyCode) {
			case KeyEvent.VK_N:
				newMode = ObjectsEditMode.NONE;
				break;
			}
			if (newMode != null) {
				button = objectsButtonsMap.get(newMode);
				currentObjectsEditMode = newMode;
			}

		}
		if (button != null) {
			button.setSelected(true);
			// Container pc = button.getParent();
			// button.scrollRectToVisible(pc.getBounds());
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	void backup(File file) {
		try {
			if (file.exists()) {
				File backupFile = new File(backupDir + "\\"
						+ System.currentTimeMillis() + file.getName());

				InputStream in = new FileInputStream(file);

				// For Append the file.
				// OutputStream out = new FileOutputStream(f2,true);

				// For Overwrite the file.
				OutputStream out = new FileOutputStream(backupFile);

				byte[] buf = new byte[1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				in.close();
				out.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	interface EditModeInterface {
	}

	interface EditModeWithProperties extends EditModeInterface {
		public LinkedHashMap<String, Object> getNewDefaultProperties();

		public LinkedHashMap<String, ? extends EditModeWithProperties> getStringToModeMap();
	}

	public enum EditMode implements EditModeInterface {
		BACKGROUND_TILES("Background Tiles"), SURFACE_TILES("Surface Tiles"), OBJECTS(
				"Objects"), OBJECT_PROPERTIES("Object Properties"), DECORATIONS(
				"Decorations");

		private String guiName;

		private EditMode(String name) {
			this.guiName = name;
		}

		public String getGuiName() {
			return guiName;
		}
	}

	void createPropertiesPanel() {
		if (propertiesPanel == null) {
			propertiesPanel = new JPanel();
			propertiesPanel.setLayout(new BoxLayout(propertiesPanel,
					BoxLayout.Y_AXIS));
		}
	}

	void updatePropertiesPanel(LinkedHashMap<String, Object> map) {
		propertiesPanel.removeAll();
		if (map != null) {
			for (String property : map.keySet()) {
				if (property.equals("x") || property.equals("y")
						|| property.equals("symbol") || property.equals("w")
						|| property.equals("h")) {
					// Some of the properit
					continue;
				}
				Object value = map.get(property);
				if (value != null) {
					JPanel valuePanel = new JPanel();
					valuePanel.add(new JLabel(property));
					JTextField tf = new JTextField(value.toString());
					valuePanel.add(tf);
					propertiesPanel.add(valuePanel);
				}
			}
			controlPanel.validate();
			controlPanel.repaint();
		}
	}

	void createControlPanel() {
		controlPanel = new JPanel();
		controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));

		JButton undoButton = new JButton("Undo");
		undoButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (tabbedPanel != null) {
					LevelPanel levelPanel = getActiveLevelPanel();
					if (levelPanel != null) {
						levelPanel.undo();
					} else {
						System.out.println("level panel null?");
					}
				} else {
					System.out.println("tabbed panel null?");
				}
			}
		});
		controlPanel.add(undoButton);

		// Edit mode panel
		currentEditMode = EditMode.BACKGROUND_TILES;
		JPanel modePanel = new JPanel();
		modePanel.setBorder(BorderFactory.createTitledBorder("Edit Mode"));
		modePanel.setLayout(new BoxLayout(modePanel, BoxLayout.Y_AXIS));
		controlPanel.add(modePanel);
		ButtonGroup editButtonGroup = new ButtonGroup();
		for (final EditMode mode : EditMode.values()) {
			String guiName = mode.getGuiName();
			final JRadioButton rb = new JRadioButton(guiName,
					mode == currentEditMode);
			rb.setFocusable(false);
			editButtonGroup.add(rb);
			modePanel.add(rb);
			modeButtonsMap.put(mode, rb);
			rb.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					currentEditMode = mode;
				}
			});
		}

		// Background tiles
		currentBackgroundTilesEditMode = BackgroundTilesEditMode.ROCK;
		backgroundTilesPanel = new JPanel();
		backgroundTilesPanel.setBorder(BorderFactory
				.createTitledBorder("Background Tiles"));
		backgroundTilesPanel.setLayout(new BoxLayout(backgroundTilesPanel,
				BoxLayout.Y_AXIS));
		controlPanel.add(backgroundTilesPanel);
		ButtonGroup backgroundTilesButtonGroup = new ButtonGroup();
		for (final BackgroundTilesEditMode mode : BackgroundTilesEditMode
				.values()) {
			String guiName = mode.getGuiName();
			final JRadioButton rb = new JRadioButton(guiName,
					mode == currentBackgroundTilesEditMode);
			backgroundsButtonsMap.put(mode, rb);
			rb.setFocusable(false);
			backgroundTilesButtonGroup.add(rb);
			backgroundTilesPanel.add(rb);
			rb.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					currentBackgroundTilesEditMode = mode;
				}
			});
		}

		// Surface tiles
		currentSurfaceTilesEditMode = SurfaceTilesEditMode.GRASS;
		JPanel surfaceTilesPanel = new JPanel();
		surfaceTilesPanel.setBorder(BorderFactory
				.createTitledBorder("Surface Tiles"));
		surfaceTilesPanel.setLayout(new BoxLayout(surfaceTilesPanel,
				BoxLayout.Y_AXIS));
		controlPanel.add(surfaceTilesPanel);
		ButtonGroup surfaceTilesButtonGroup = new ButtonGroup();
		for (final SurfaceTilesEditMode mode : SurfaceTilesEditMode.values()) {
			String guiName = mode.getGuiString();
			final JRadioButton rb = new JRadioButton(guiName,
					mode == currentSurfaceTilesEditMode);
			surfacesButtonsMap.put(mode, rb);
			rb.setFocusable(false);
			surfaceTilesButtonGroup.add(rb);
			surfaceTilesPanel.add(rb);
			rb.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					currentSurfaceTilesEditMode = mode;
				}
			});
		}

		// Objects
		currentObjectsEditMode = ObjectsEditMode.NONE;
		JPanel objectsPanel = new JPanel();
		objectsPanel.setBorder(BorderFactory.createTitledBorder("Objects"));
		objectsPanel.setLayout(new BoxLayout(objectsPanel, BoxLayout.Y_AXIS));
		controlPanel.add(objectsPanel);
		ButtonGroup objectsButtonGroup = new ButtonGroup();
		for (final ObjectsEditMode mode : ObjectsEditMode.values()) {
			String guiName = mode.getGuiString();
			final JRadioButton rb = new JRadioButton(guiName,
					mode == currentObjectsEditMode);
			objectsButtonsMap.put(mode, rb);
			rb.setFocusable(false);
			objectsButtonGroup.add(rb);
			objectsPanel.add(rb);
			rb.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					currentObjectsEditMode = mode;
				}
			});
		}

		// Decorations
		currentDecorationsEditMode = DecorationsEditMode.NONE;
		JPanel decorationsPanel = new JPanel();
		decorationsPanel.setBorder(BorderFactory
				.createTitledBorder("Decorations"));
		decorationsPanel.setLayout(new BoxLayout(decorationsPanel,
				BoxLayout.Y_AXIS));
		controlPanel.add(decorationsPanel);
		ButtonGroup decorationsButtonGroup = new ButtonGroup();
		for (final DecorationsEditMode mode : DecorationsEditMode.values()) {
			String guiName = mode.getGuiString();
			final JRadioButton rb = new JRadioButton(guiName,
					mode == currentDecorationsEditMode);
			decorationsButtonsMap.put(mode, rb);
			rb.setFocusable(false);
			decorationsButtonGroup.add(rb);
			decorationsPanel.add(rb);
			rb.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					currentDecorationsEditMode = mode;
				}
			});
		}

		// Paint mode
		currentPaintMode = PaintMode.PENCIL;
		JPanel paintModePanel = new JPanel();
		paintModePanel
				.setBorder(BorderFactory.createTitledBorder("Paint Mode"));
		paintModePanel
				.setLayout(new BoxLayout(paintModePanel, BoxLayout.Y_AXIS));
		controlPanel.add(paintModePanel);
		ButtonGroup paintModeButtonGroup = new ButtonGroup();
		for (final PaintMode mode : PaintMode.values()) {
			String guiName = mode.getGuiString();
			final JRadioButton rb = new JRadioButton(guiName,
					mode == currentPaintMode);
			rb.setFocusable(false);
			paintModeButtonGroup.add(rb);
			paintModePanel.add(rb);
			rb.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					currentPaintMode = mode;
				}
			});
		}

		// Object properties
		createPropertiesPanel();
		controlPanel.add(propertiesPanel);
	}

	LevelPanel getActiveLevelPanel() {
		Component selectedComponent = tabbedPanel.getSelectedComponent();
		LevelPanel levelPanel = tabComponentsLevelPanelMap
				.get(selectedComponent);
		return levelPanel;
	}

	public LevelEditor() {
		super("Level Editor");
		setSize(1024, 768);

		JMenuBar menuBar = new JMenuBar();

		JMenu fileMenu = new JMenu("File");

		ArrayList<Level> loadedLevels = null;

		// Load the xml-file if it exists
		File xmlFile = new File(xmlSaveFile);
		if (xmlFile.exists()) {
			try {
				Element rootElement = XMLUtils.parseAndGetElement(xmlFile);
				ArrayList<Element> childrenElements = XMLUtils
						.getChildrenElements(rootElement);
				for (Element e : childrenElements) {
					String tagName = e.getTagName();
					if (tagName.equals("level")) {
						Level level = Level.readFromElement(e);
						// System.out.println("reading level: " +
						// level.toXml());
						if (loadedLevels == null) {
							loadedLevels = new ArrayList<Level>();
						}
						loadedLevels.add(level);
					} else {
						System.out.println("unknown level tag in level editor");
					}

				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

		JMenuItem saveItem = new JMenuItem("Save");

		saveItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				// Saving the xml file
				StringBuilder builder = new StringBuilder();
				builder.append("<level_pack>\n");
				for (LevelPanel panel : tabComponentsLevelPanelMap.values()) {
					panel.level.toXml(builder);
				}
				builder.append("</level_pack>\n");
				File xmlFile = new File(xmlSaveFile);
				backup(xmlFile);
				try {
					FileUtils.writeToFile(xmlFile, builder.toString());
				} catch (Exception e1) {
					e1.printStackTrace();
				}

				// Saving javascript data (no backup)
				StringBuilder jsBuilder = new StringBuilder();
				jsBuilder.append("var levels = [");
				ArrayList<LevelPanel> panelList = new ArrayList<LevelPanel>(
						tabComponentsLevelPanelMap.values());
				for (int i = 0; i < panelList.size(); i++) {
					LevelPanel panel = panelList.get(i);
					panel.level.toJavaScript(jsBuilder);
					if (i < panelList.size() - 1) {
						jsBuilder.append(",\n");
					}
				}
				jsBuilder.append("];\n");
				File jsFile = new File(jsSaveFile);
				try {
					FileUtils.writeToFile(jsFile, jsBuilder.toString());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		fileMenu.add(saveItem);

		menuBar.add(fileMenu);
		setJMenuBar(menuBar);

		JPanel mainPanel = new JPanel(new BorderLayout());

		tabbedPanel = new JTabbedPane();

		if (loadedLevels == null) {
			// Add some default levels
			loadedLevels = new ArrayList<Level>();
			int[] levelDepths = new int[] { 100, 120, 120, 150, 200 };
			int[] levelWidths = new int[] { 40, 80, 120, 40, 500 };
			for (int i = 0; i < 5; i++) {
				Level level = new Level(i, levelWidths[i], levelDepths[i]);
				loadedLevels.add(level);
			}
		}
		for (int i = 0; i < loadedLevels.size(); i++) {
			Level level = loadedLevels.get(i);
			LevelPanel levelPanel = new LevelPanel(level, this);
			levelPanel.setFocusable(true);
			levelPanel.addMouseListener(new FocusMouseListener(levelPanel));
			levelPanel.addKeyListener(this);
			JScrollPane sp = new JScrollPane(levelPanel);
			tabbedPanel.addTab("Level " + (i + 1), sp);
			tabComponentsLevelPanelMap.put(sp, levelPanel);
		}
		mainPanel.add(tabbedPanel, BorderLayout.CENTER);

		createControlPanel();
		JScrollPane sp = new JScrollPane(controlPanel);
		mainPanel.add(sp, BorderLayout.EAST);

		controlPanel.setFocusable(true);
		// this.getContentPane().setFocusable(true);
		// this.getContentPane().addKeyListener(this);
		mainPanel.setFocusable(true);
		mainPanel.addKeyListener(this);
		controlPanel.addKeyListener(this);

		mainPanel.addMouseListener(new FocusMouseListener(mainPanel));
		controlPanel.addMouseListener(new FocusMouseListener(controlPanel));

		add(mainPanel);
	}

	class FocusMouseListener extends MouseAdapter {
		JPanel panel;

		public FocusMouseListener(JPanel panel) {
			this.panel = panel;
		}

		@Override
		public void mousePressed(MouseEvent e) {
			panel.requestFocusInWindow();
		}

	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				LevelEditor levelEditor = new LevelEditor();
				levelEditor.setDefaultCloseOperation(EXIT_ON_CLOSE);
				levelEditor.setVisible(true);
			}
		});
	}

}
