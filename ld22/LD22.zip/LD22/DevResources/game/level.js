//


Level = {};

Level.levelInfos = [
	{filename: "level_1.json", name: "level1", type: "level", finalLevel: true, nextLevel: "level2"} // Other types like vehicle, animation object, etc. can be here to
//	{filename: "level_2.json", name: "level2", type: "level", finalLevel: true, nextLevel: ""} // 
];


Level.levelsLoaded = false;

Level.levels = {};

Level.levelStrings = {};

var player = null;




Level.releaseStarCharge = function(obj) {

	var charge = obj.starCharge;
	
	var newP = new ChargeParticle(obj);
	var added = false;
	for (var i = 0; i<chargeParticles.length; i++) {
		var p = chargeParticles[i];
		if (p == null) {
			chargeParticles[i] = newP;
			added = true;
			break;
		}
	}
	
	if (!added) {
		chargeParticles.push(newP);
	}
	// chargeParticles.push(p);
}


Level.getPickupAt = function(rect) {

	var startX = Math.floor(rect[0] / 32);
	var startY = Math.floor(rect[1] / 32);
	var endX = Math.ceil((rect[0] + rect[2]) / 32);
	var endY = Math.ceil((rect[1] + rect[3]) / 32);

	// logitRnd("intersect test: " + startX + " " + startY + " " + endX + " " + endY + "\n", 0.02);
	
	var level = currentLevel;
	
	if (!rectCollide(rect, [0, 0, level.width * 32, level.height * 32])) {
		// Outside level
		return NO_PICKUP;
	}

	// logitRnd("Checking pickup
	
	for (var x=startX; x<=endX; x++) {
		for (var y=startY; y<=endY; y++) {
			var index = x + y * level.width;
			var data = level.pickupLayer.data[index];
			if (data != 0 && rectCollide(rect, [x*32, y*32, 32, 32])) {
				var pickedUp = false;
				switch (data) {
					case 135: // Star power
						if (player.starPower < player.maxStarPower) {
							player.starPower = Math.min(player.maxStarPower, player.starPower + 0.5);
							pickedUp = true;
							Sound.play(Sound.STAR_PICKUP_ID);
						}
						break;
					case 136: // Health
						if (player.health < player.maxHealth) {
							player.health = Math.min(player.maxHealth, player.health + 0.5);
							pickedUp = true;
							Sound.play(Sound.HEALTH_PICKUP_ID);
						}
						break;
				}
				if (pickedUp) {
					level.pickupLayer.data[index] = 0;
				}
			}
		}
	}
	
}


Level.reloadLevel = function() {
	Level.readLevel(currentLevelName, null);	
	currentLevel = Level.levels[currentLevelName];
}

Level.loadNextLevel = function() {
	currentLevelName = currentLevel.nextLevelName;
	Level.readLevel(currentLevel.nextLevelName, null);	
	currentLevel = Level.levels[currentLevel.nextLevelName];
}

Level.loadInitialLevel = function() {
	currentLevelName = initialLevelName;
	Level.readLevel(initialLevelName, null);
	currentLevel = Level.levels[initialLevelName];
}



Level.hitImpulse = function(sourceObj, impulseInfo) {
	// Check collisions between agents
	var objects = currentLevel.objectLayers[0].objects;
	
	var hitX = impulseInfo.x;
	var hitY = impulseInfo.y;
	
	var checkRect = [hitX - impulseInfo.width/2, hitY - impulseInfo.height/2, impulseInfo.width, impulseInfo.height];

	
	// logit("impulse.ix: " + impulseInfo.ix + "\n");
	// logit("impulse.iy: " + impulseInfo.iy + "\n");

	
	for (var i=0; i<objects.length; i++) {
		var obj = objects[i];
		
		if (!obj.dead && obj != sourceObj) {
		
			var hitRect = [obj.x - obj.physicalWidth / 2, obj.y - obj.physicalHeight / 2, obj.physicalWidth, obj.physicalHeight];
			var hit = rectCollide(hitRect, checkRect);
			
			// logit("hitrect: " + hitRect + " hitvec: " + hitVec + "\n");
			
			if (hit) {
				Sound.play(Sound.HIT_1_ID);
				// logit("Adding modifier: " + impulseInfo.impulseX + "\n");
				obj.velocityModifiers.push({vx: impulseInfo.impulseX, vy: impulseInfo.impulseY, duration: impulseInfo.duration});
				obj.health -= impulseInfo.damage;
				if (obj.health <= 0) {
					obj.die();
				}
			}
		}
	}
	
}

Level.intersectLevel = function(level, rect) {
	var startX = Math.floor(rect[0] / 32);
	var startY = Math.floor(rect[1] / 32);
	var endX = Math.ceil((rect[0] + rect[2]) / 32);
	var endY = Math.ceil((rect[1] + rect[3]) / 32);

	// logitRnd("intersect test: " + startX + " " + startY + " " + endX + " " + endY + "\n", 0.02);

	
	if (!rectCollide(rect, [0, 0, level.width * 32, level.height * 32])) {
		// Outside level
		return true;
	}
	
	
	for (var x=startX; x<endX; x++) {
		for (var y=startY; y<endY; y++) {
			var data = level.solidLayer.data[x + y * level.width];
			if (data != 0 && rectCollide(rect, [x*32, y*32, 32, 32])) {
				return true;
			}
		}
	}
	return false;
}



Level.setupLevel = function(levelName) {
	var level = Level.levels[levelName];
	
	var oldRandom = Math.random;
	
	level.randomSeed = Math.seedrandom(levelName);
	level.random = Math.random;

	level.objectLayers = [];
	level.tileLayers = [];
	level.aboveLayers = [];
	level.solidLayer = null;
	level.pickupLayer = null;

	for (var i=0; i<Level.levelInfos.length; i++) {
		var levelInfo = Level.levelInfos[i];
		if (levelInfo.name == levelName) {
			level.finalLevel = levelInfo.finalLevel;
			level.nextLevelName = levelInfo.nextLevel;
			break;
		}
	}
	
	
	for (var i=0; i<level.layers.length; i++) {
		var layer = level.layers[i];
		if (layer.type == "tilelayer") {
			// Can be a solid layer
			if (layer.name == "Solidness") {
				level.solidLayer = layer;
			} else if (layer.name == "Above Ground") {
				level.aboveLayers.push(layer);
			} else if (layer.name == "Pickup") {
				level.pickupLayer = layer;
				level.tileLayers.push(layer); // Crappy solution...
			} else {
				level.tileLayers.push(layer);
			}
		} else if (layer.type == "objectgroup") {
			level.objectLayers.push(layer);
		} else {
			logitRnd("Unknown layer type " + layer.type + "\n", 0.1);
		}
	}
	
	
	for (var i=0; i<level.layers.length; i++) {
		var layer= level.layers[i];
		if (layer.type == "objectgroup") {
			var objects = layer.objects;
			
			// Add methods and properties to objects
			for (var j=0; j<objects.length; j++) {
				var o = objects[j];
				o.image = ImageHandler.images.tiles; // For now...
				
				o.maxHealth = 1.0;
				o.maxStarPower = 0;
				o.hitDamage = 0.501;
				o.hitPeriod = 30;
				o.hitPeriod2 = 20;
				o.hitImpulse = 4;
				o.die = enemyDie;
				o.dead = false;
				o.aiMode = PATROLLING;
				o.oldBotBehaveInfo = null;
				o.counter = 100;
				o.decisionPeriod = 10;
				o.maxSpeed = 2;
				o.charging = false;
				o.currentCharge = 0;
				o.headType = 0;
				o.starCharge = 0;
				
				var isHumanoid = true;
				
				switch (o.type) {
					case "kid 1":
						o.paint = paintKid;
						o.step = stepKid;
						o.physicalWidth = 20;
						o.physicalHeight = 20;
						o.visualWidth = 64;
						o.visualHeight = 64;
						o.spriteGridX = 0;
						o.spriteGridY = 10;
						o.maxHealth = 1.2;
						o.hitDamage = 0.2;
						o.hitImpulse = 3;
						break;
					case "kid 2":
						o.paint = paintKid;
						o.step = stepKid;
						o.physicalWidth = 20;
						o.physicalHeight = 20;
						o.visualWidth = 64;
						o.visualHeight = 64;
						o.spriteGridX = 0;
						o.spriteGridY = 12;
						o.maxHealth = 1.2;
						o.hitPeriod = 27;
						o.hitPeriod2 = 15;
						o.hitDamage = 0.25;
						o.maxSpeed = 2.2;
						o.hitImpulse = 4;
						break;
					case "kid 3":
						o.paint = paintKid;
						o.step = stepKid;
						o.physicalWidth = 20;
						o.physicalHeight = 20;
						o.visualWidth = 64;
						o.visualHeight = 64;
						o.spriteGridX = 0;
						o.spriteGridY = 14;
						o.maxHealth = 2.0;
						o.hitPeriod = 24;
						o.hitPeriod2 = 15;
						o.hitDamage = 0.27;
						o.maxSpeed = 2.5;
						o.hitImpulse = 5;
						break;
					case "player":
						o.paint = paintPlayer;
						o.step = stepPlayer;
						o.physicalWidth = 20;
						o.physicalHeight = 20;
						o.visualWidth = 64;
						o.visualHeight = 64;
						o.spriteGridX = 0;
						o.spriteGridY = 8;
						o.maxHealth = 1.5;
						o.maxStarPower = 1.0;
						o.die = playerDie;
						o.headType = 0;
						o.hitPeriod = 27;
						o.hitPeriod2 = 15;
						o.maxSpeed = 3;
						o.hitImpulse = 4;
						player = o;
						break;
					default:
						logit("discovered unknown object type: " + o.type + "\n");
						break;
				}

				if (isHumanoid) {
					o.health = o.maxHealth;
					o.starPower = o.maxStarPower;
					o.vx = 0;
					o.vy = 0;
					o.animationState = 0;
					o.turnedRight = true;
					o.animationCounter = 0;
					o.hitImpulseSourceX = 20;
					o.hitImpulseSourceY = 0;
					o.hitCounter = 100;
					o.velocityModifiers = [];
				}
				// logit("spriteRect: " + spriteRect + " image.width: " + o.spriteImage.width + "\n");
				
			}
		}
	}
}

Level.getSpriteRect = function(obj, xStep, yStep) {
	return [(obj.spriteGridX) * 32 + obj.visualWidth * xStep, (obj.spriteGridY) * 32 + obj.visualHeight * yStep, obj.visualWidth, obj.visualHeight];
} 

Level.readLevel = function(name, filename) {
	if (Level.levels[name]) {
		// Level already exists
		// Parse json string again to reset
		Level.levels[name] = $.parseJSON(Level.levelStrings[name]);
		// logit("Reloading level " + name + "\n");
		Level.setupLevel(name);
	} else {
	
		var request = $.ajax({
			  type: "GET",
			  url: filename,
			  dataType: "text",
			  async: false,
			  success: function(data) {
				// logit("Loaded level with name " + name + "\n");
				Level.levelStrings[name] = data;
				Level.levels[name] = $.parseJSON(data);
				Level.setupLevel(name);
			  },
			  error: function(jqXHR, textStatus, errorThrown) {
				logit("error " + jqXHR + " " + textStatus + " " + errorThrown + "\n");		  
			  },
			  complete: function(jqXHR, textStatus) {
				// logit("complete " + jqXHR + " " + textStatus + "\n");
			  }
			});
		
		
		// $.getJSON(filename, {}, function(data) {
			// Level.levels[name] = data;
			// logit("Read " + name + " level\n");
		// });
	}
}


Level.init = function() {

	for (var i=0; i<Level.levelInfos.length; i++) {
		var info = Level.levelInfos[i];
		
		if (info.type = "level") {
			Level.readLevel(info.name, info.filename);
		}
	}	
}
