var ImageHandler = {};

ImageHandler.images = {};
ImageHandler.allLoaded = false;

ImageHandler.percentDone = 0.0;
 
ImageHandler.loadImages = function(sources, callback){
	var loadedImages = 0;
	var numImages = 0;
	// get num of sources
	for (var src in sources) {
	    numImages++;
	}
	for (var src in sources) {
	    ImageHandler.images[src] = new Image();
	    ImageHandler.images[src].onload = function(){
	        if (++loadedImages >= numImages) {
	            callback();
	        }
	    };
		if (numImages > 0) {
			ImageHandler.percentDone = Math.round(100.0 * Math.min(1.0, (loadedImages / numImages)));
		} else {
			ImageHandler.percentDone = 100;
		}
	    ImageHandler.images[src].src = sources[src];
	}	
};


ImageHandler.init = function(ctx) {
	
	var sources = {
        tiles: "tiles.png",
		font: "font.png",
		title: "title.png"
    };
 
	
    ImageHandler.loadImages(sources, function(){
		// ImageHandler.processTiles(ctx);
		ImageHandler.allLoaded = true;
    });
}