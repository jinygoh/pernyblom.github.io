var Sound = {};

Sound.BLIP_1_ID = 1;
Sound.BUTTON_PRESS_1_ID = 2;
Sound.CHARGE_ID = 3;
Sound.HIT_1_ID = 4;
Sound.RELEASE_ID = 5;
Sound.TRY_HIT_ID = 6;
Sound.HEALTH_PICKUP_ID = 7;
Sound.STAR_PICKUP_ID = 8;

Sound.HAPPY_MUSIC_ID = 20;

Sound.sounds = [];
Sound.loaded = [];
Sound.allLoaded =false;
Sound.smInitiated = false;
Sound.loadedSounds = 0;
Sound.percentDone = 0.0;

Sound.mute = false;

Sound.init = function() {

	soundManager.debugMode = false;
	soundManager.url = '';
	soundManager.useHTML5Audio = true;
	soundManager.preferFlash = false;
	
	soundManager.onready(function() {
		var sounds = [
		{name: "happyMusic", intId: Sound.HAPPY_MUSIC_ID, filename: "happy_music.mp3"},
		{name: "blip1", intId: Sound.BLIP_1_ID, filename: "blip_1.mp3"},
		{name: "buttonPress1", intId: Sound.BUTTON_PRESS_1_ID, filename: "button_press_1.mp3"},
		{name: "charge", intId: Sound.CHARGE_ID, filename: "charge.mp3"},
		{name: "hit1", intId: Sound.HIT_1_ID, filename: "hit_1.mp3"},
		{name: "release", intId: Sound.RELEASE_ID, filename: "release.mp3"},
		{name: "tryHit", intId: Sound.TRY_HIT_ID, filename: "try_hit.mp3"},
		{name: "starPickup", intId: Sound.STAR_PICKUP_ID, filename: "star_pickup.mp3"},
		{name: "healthPickup", intId: Sound.HEALTH_PICKUP_ID, filename: "health_pickup.mp3"}
		];
		
		Sound.soundInfoArray = sounds;
		for (var i = 0; i < sounds.length; i++) {
			var soundInfo = sounds[i];
			var sound = soundManager.createSound({
				id: soundInfo.name,
				url: soundInfo.filename,
				autoLoad: true,
				autoPlay: false,
				onload: function() {
					Sound.loaded[soundInfo.intId] = true;
					Sound.loadedSounds++;
					Sound.percentDone = Math.round(100.0 * Math.min(1.0, (Sound.loadedSounds / Sound.soundInfoArray.length)));
				},
				volume: 50
			});
			Sound.sounds[soundInfo.intId] = sound;
		}
		Sound.smInitiated = true;
	});

}

Sound.isPlaying = function(soundId) {
	if (Sound.smInitiated) {
		var sound = Sound.sounds[soundId];
		if (typeof sound != "undefined") {
			return sound.playState == 1;
		}
	}
	return false;
}

Sound.play = function(soundId, options) {
	if (Sound.smInitiated && !Sound.mute) {
		if (options) {
			Sound.sounds[soundId].play(options);
		} else {
			Sound.sounds[soundId].play();
		}
	}
}

Sound.stop = function(soundId) {
	if (Sound.smInitiated) {
		// if (Sound.loaded[soundId]) {
		Sound.sounds[soundId].stop();
		// }
	}
}

Sound.muteSound = function() {
	Sound.stop(Sound.MUSIC_ID_1);
	Sound.mute = true;
}

Sound.unMuteSound = function() {
	Sound.mute = false;
}

