// Font stuff
var Font = {};

var FontInfos = {
	smallFont: {
		fontStringArr: ["ABCDEFGHIJKLMNOPQRSTUVWXYZ", "0123456789.,!><+-;:?* "],
		width: 10,
		height: 10,
		imageName: "font"
	}
}


Font.initFont = function(fontInfo) {
	var arr = fontInfo.fontStringArr;
	var map = new Map();
	fontInfo.map = map;
	for (var i =0; i<arr.length; i++) {
		var str = arr[i];
		for (var j=0; j<str.length; j++) {
			var ch = str.charAt(j);
			map.put(ch, [j, i]);
		}
	}
}

Font.init = function() {

	Font.initFont(FontInfos.smallFont);
	
}

Font.drawString = function(x, y, str, fontInfo, scale) {
	if (!fontInfo.image) {
		fontInfo.image = ImageHandler.images[fontInfo.imageName];
	}
	if (!scale) {
		scale = 1;
	}
	
	var image = fontInfo.image;
	var w = fontInfo.width;
	var h = fontInfo.height;
	var vw = fontInfo.width * scale;
	var vh = fontInfo.height * scale;
	for (var i=0; i<str.length; i++) {
		var ch = str.charAt(i);
		var coords = fontInfo.map.get(ch);
		if (typeof coords == "undefined") {
		} else {
			ctx.drawImage(image, coords[0] * w, coords[1] * h, w, h, x + i * vw, y, vw, vh);
		}
	}
}

