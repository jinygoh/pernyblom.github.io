

var canvas = null; // document.getElementById("mainCanvas");
var ctx = null; // canvas.getContext("2d");
var output = null; // document.getElementById("output");

var beforeClearColor = "#000000";

var state = MAIN_MENU;

var targetState = -1;
var switchingState = false; // For keeping track of state transitions. Combined with stateCounter and stateCounter2.
var stateCounter = 0; // Counter for keeping track of the states such as fadeouts/ins etc.
var endStateCounter = 0; // When the stateCounter is supposed to stop counting and do something (such as switch state)
var stateCounter2 = 0; // Secondary counter

var initialLevelName = "level1";
var currentLevelName = "level1";
var currentLevelFilename = "level_1.json";
var currentLevel = null;

var paused = false;
var dying = false;
var winning = false;

var TestClass = function(args) {
	if (args) {
		this.x = args.x;
	}
}

TestClass.prototype.aMethod = function() {
	this.x += 0.1;
}

var TestSubClass = function(args) {
	TestClass.call(this, args);
}

TestSubClass.prototype = new TestClass();


window.requestAnimFrame = (function(){
	return window.requestAnimationFrame    || 
		window.webkitRequestAnimationFrame || 
		window.mozRequestAnimationFrame    || 
		window.oRequestAnimationFrame      || 
		window.msRequestAnimationFrame     || 
		function(/* function */ callback, /* DOMElement */ element){
		window.setTimeout(callback, 1000 / 60);
		};
	})();


function init() {

	
	
	canvas = document.getElementById("mainCanvas");
	if (canvas == null) {
		alert(canvas);
	}
	ctx = canvas.getContext("2d");
	output = document.getElementById("output");

	
	beforeClearColor = "#000000";	
	
	ImageHandler.init(ctx);
	Font.init();
	Input.init();
	Level.init();
		
	mainLoop();
}

function logit(str) {
	if (output) {
		output.innerHTML += str;
	}
}

function logitRnd(str, prob) {
	if (Math.random() < prob) {
		if (output) {
			output.innerHTML += str;
		}
	}
}


// Delays a state transition
function transitionToState(newState) {
	stateCounter++;
	if (stateCounter > endStateCounter) {
		switchingState = false;
		state = newState;
		stateCounter = 0;
		return true; // Done
	} else {
		// Still not done
		return false;
	}
	return true; // Done
}


var stepMillis = -1;

function mainLoop() {

	if (currentLevel == null) {
		currentLevel = Level.levels[initialLevelName];
	}
	
	
	if (!ImageHandler.allLoaded) {

		// Clearing
		ctx.fillStyle="black";
		ctx.fillRect(0, 0, canvas.width, canvas.height);

		ctx.strokeStyle = "#ffffff";
		ctx.lineWidth = 1;
		ctx.font = "12px sans-serif";
		// in DOMString text, in double x, in double y, in optional double maxWidth);
		ctx.strokeText("Loading... Please Wait", 10, 20);
		ctx.strokeText("Sounds Loaded: " + Sound.percentDone + "%", 10, 35);
		ctx.strokeText("Images Loaded: " + ImageHandler.percentDone + "%", 10, 50);
	}

	var d = new Date();
	var currentMillis = d.getTime();
	var updateMillis = 12; // The preferred rate for updating the game "physics"

	if (stepMillis == -1) {
		stepMillis = currentMillis;
		preferredStepMillis = currentMillis + 1; // Just to make sure that we step the first time
	} else {
		preferredStepMillis = currentMillis; // Where we should be now
	}
		
	var doPaint = ImageHandler.allLoaded;
	// Stepping	
	var maxSteps = 6;
	for (var i=0; i<maxSteps; i++) {

		if (stepMillis > preferredStepMillis) {
			// We are done stepping
			if (i == 0) {
				doPaint = false;
			}
			break;
		} else if (i == maxSteps - 1) {
			// Reached max steps
			d = new Date();
			currentMillis = d.getTime();
			stepMillis = currentMillis; // Pretend that we actually are there
		} else {
			// We are progressing towards the goal preferredStepMillis
			stepMillis += updateMillis;
		}

		// Step game here...
		switch (state) {
			case PLAYING:
				stepPlaying();
				break;
			case MAIN_MENU:
				stepMainMenu();
				break;
			case HOW_TO_PLAY_MENU:
				stepHowToPlayMenu();
				break;
			case CREDITS_MENU:
				stepCreditsMenu();
				break;
		}
		
		Input.step();
	}

	// Stepping input (resets just pressed etc)
	
	if (doPaint) {
	// paint here
		ctx.fillStyle="black";
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		switch (state) {
			case PLAYING:
				paintPlaying();
				break;
			case MAIN_MENU:
				paintMainMenu();
				break;
			case HOW_TO_PLAY_MENU:
				paintHowToPlayMenu();
				break;			
			case CREDITS_MENU:
				paintCreditsMenu();
				break;			
		}
		paintMouseCursor();
	}
	requestAnimFrame(mainLoop);
}




Sound.init();

$(document).ready(function()
    {
        // The DOM (document object model) is constructed
 		init();
    });

