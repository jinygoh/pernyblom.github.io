// Just a placeholder for constants...

// States
var PLAYING = 0;
var MAIN_MENU = 1;
var HOW_TO_PLAY_MENU = 2;
var CREDITS_MENU = 3;


// AI modes
var IDLE = 0;
var ATTACKING = 1;
var PATROLLING = 2;


// Pickups
var NO_PICKUP = -1;
var HEALTH = 0;
var POWER = 1;
