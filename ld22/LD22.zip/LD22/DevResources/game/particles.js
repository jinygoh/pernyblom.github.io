// particles

function MenuStarParticle(x, y, vx, vy, angle, w, scale, alpha, alphaDelta) {
	this.x = x;
	this.y = y;
	this.scale = scale;
	this.angle = angle;
	this.w = w;
	this.vx = vx;
	this.vy = vy;
	this.alpha = alpha;
	this.alphaDelta = alphaDelta;
	this.maxAlpha = 1.0;
	this.minAlpha = 0.0;
}

MenuStarParticle.prototype.paint = function() {

	if (this.alpha > 0.0) {
		var oldAlpha = ctx.globalAlpha;

		ctx.save();

		ctx.translate(this.x, this.y);

		ctx.rotate(this.angle);
		ctx.translate(-32, -32);
		// ctx.scale(this.scale, this.scale);
		
		ctx.globalAlpha = this.alpha;
		ctx.drawImage(ImageHandler.images.tiles, 6 * 32, 6 * 32, 64, 64, 0, 0, 64, 64);
		
		ctx.restore();
		
		// ctx.fillStyle = "#ff0000";
		// ctx.fillRect(this.x - 5, this.y - 5, 10, 10);
		
		ctx.globalAlpha = oldAlpha;
	}
}

MenuStarParticle.prototype.step = function() {
	this.angle += this.w;
	this.x += this.vx;
	this.y += this.vy;
	this.alpha += this.alphaDelta;
	if (this.alpha > this.maxAlpha || this.alpha < this.minAlpha) {
		this.alphaDelta *= -1;
		if (this.alpha > this.maxAlpha) {
			this.alpha = this.maxAlpha;
		} else {
			this.alpha = this.minAlpha;
		}
	}
	if (this.x > canvas.width + 100) {
		this.x = -90;
	}
	
	if (this.x < -100) {
		this.x = canvas.width + 90;
	}
	if (this.y > canvas.height + 100) {
		this.y = -90;
	}
	
	if (this.y < -100) {
		this.y = canvas.height + 90;
	}
}