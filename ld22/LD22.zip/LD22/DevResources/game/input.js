var Input = {};

Input.down = [];
Input.pressed = [];
Input.leftKey = 37;
Input.upKey = 38;
Input.rightKey = 39;
Input.downKey = 40;

Input.oneKey = 49;
Input.twoKey = 50;
Input.threeKey = 51;

Input.enterKey = 13;

Input.aKey = 65;
Input.wKey = 87;
Input.sKey = 83;
Input.dKey = 68;

Input.zKey = 90;
Input.xKey = 88;
Input.cKey = 67;
Input.vKey = 86;
Input.bKey = 66;

Input.qKey = 81;
Input.eKey = 69;
Input.spaceKey = 32;
Input.ctrlKey = 17;
Input.escapeKey = 27;

Input.mouseDown = false;
Input.mouseJustPressed = false;

Input.rightMouseDown = false;
Input.rightMouseJustPressed = false;

Input.mouseX = 0;
Input.mouseY = 0;

Input.keyDown = function(key) {
	return Input.down[key];
	// for (var i=0; i<Input.down.length; i++) {
		// if (Input.down[i] == key) {
			// return true;
		// }
	// }
	// return false;
}


Input.anyOfTheseKeysDown = function(keys) {
	for (var i=0; i<keys.length; i++) {
		if (Input.down[keys[i]]) {
			return true;
		}
	}
	return false;
}


Input.anyKeyJustPressed = function() {
	return Input.pressed.length > 0;
}

Input.keyJustPressed = function(keyCode) {
	for (var i = 0; i<Input.pressed.length; i++) {
		if (Input.pressed[i] == keyCode) {
			return true;
		}
	}
	return false;
}

Input.onMouseDown = function(evt) {
	// logit("mouse down... " + evt.which + "\n");
	switch (evt.which) {
		case 1:
			Input.mouseDown = true;
			Input.mouseJustPressed = true;
			break;
		case 3:
			Input.rightMouseDown = true;
			Input.rightMouseJustPressed = true;
			evt.preventDefault();
			break;
	}
	return false;
}

Input.onMouseUp = function(evt) {
	Input.mouseDown = false;
	return false;
}

Input.setKeyUpOrDown = function(evt, down) {	
	Input.down[evt.keyCode] = down;
};


Input.onKeyDown = function(evt) {
	Input.pressed.push(evt.keyCode);
	Input.setKeyUpOrDown(evt, true);
	// evt.preventDefault();
	// logit("key down... " + evt.keyCode + "\n");
};

Input.onKeyUp = function(evt) {
	Input.setKeyUpOrDown(evt, false);
	// evt.preventDefault();
};

Input.onMouseMove = function(evt) {
	var canvasOffset = $("#mainCanvas").offset();
	
	Input.mouseX = evt.pageX - canvasOffset.left;
	Input.mouseY = evt.pageY - canvasOffset.top;
      // var pageCoords = "( " + e.pageX + ", " + e.pageY + " )";
      // var clientCoords = "( " + e.clientX + ", " + e.clientY + " )";
};

Input.init = function() {
	$(document).keydown(Input.onKeyDown);
	$(document).keyup(Input.onKeyUp);
	$("#mainCanvas").mousedown(Input.onMouseDown);
	$("#mainCanvas").mouseup(Input.onMouseUp);
	$("#document").mousemove(Input.onMouseMove);

	// Asking before leaving game
	$(window).bind('beforeunload', function(){
		return 'Really want to exit the game?';
	});
	
	// Disable context menu for the canvas
	$("#mainCanvas").bind("contextmenu",function(e){
              return false;
       }); 
	   
	// Prevent window from scrolling with arrow keys
	var ar = [33, 34, 35, 36, 37, 38, 39, 40];
	$(document).keydown(function(e) {
		var key = e.which;
		if($.inArray(key,ar) > -1) {
			e.preventDefault();
			return false;
		}
		return true;
	});
	
};

Input.step = function() {
	Input.mouseJustPressed = false;
	Input.rightMouseJustPressed = false;
	Input.pressed.length = 0;
}
