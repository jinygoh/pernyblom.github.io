// 

function createSubImage(origImage, rect, processorFunc) {
	var canvasElement = document.createElement("canvas");
	canvasElement.width = rect[2];
	canvasElement.height = rect[3];
	var tempContext = canvasElement.getContext("2d");
	
	// logit("drawing image with rect: " + rect + " and origImage " + origImage.width + ", " + origImage.height + "\n");
	
	tempContext.drawImage(origImage, rect[0], rect[1], rect[2], rect[3], 0, 0, rect[2], rect[3]);
	
	
	
	// var imageData = tempContext.getImageData(0, 0, rect[2], rect[3]);
	// for (var i=0; i<imageData.width; i++) {
		// for (var j=0; j<imageData.height; j++) {
			// var index = i * 4 + j * imageData.width * 4;
			// imageData.data[index] = 255;
			// imageData.data[index + 1] = 255;
			// imageData.data[index + 2] = 255;
			// imageData.data[index + 3] = 255;
		// }
	// }
	// tempContext.putImageData(imageData, 0, 0);
	
	
	if (processorFunc) {
		// Perform some processing on the sub image
		var imageData = tempContext.getImageData(0, 0, rect[2], rect[3]);
		processorFunc(imageData);
		tempContext.putImageData(imageData, 0, 0);
	}
	return canvasElement;
}

// Rects are represented with arrays:
// [x, y, width, height]
function rectCollide(rect1, rect2) {
	var x1 = rect1[0];
	var y1 = rect1[1];
	var x2 = rect2[0];
	var y2 = rect2[1];
	
	// y1 + height1 < y2 || y1 > y2 + height2 || x1 + width1 < x2 || x1 > x2 + width2
	return ! ( y1 + rect1[3] < y2 || y1 > y2 + rect2[3] || x1 + rect1[2] < x2 || x1 > x2 + rect2[2] )	
}

function rectContains(rect, vec) {
	var vx = vec[0];
	var vy = vec[1];
	var rx = rect[0];
	var ry = rect[1];
	var rw = rect[2];
	var rh = rect[3];
	return ! (vx < rx || vx > rx + rw || vy < ry || vy > ry + rh);
}

function rectContainsRect(rect1, rect2) {
	var r1x = rect1[0];
	var r1y = rect1[1];
	var r1w = rect1[2];
	var r1h = rect1[3];
	var r2x = rect2[0];
	var r2y = rect2[1];
	var r2w = rect2[2];
	var r2h = rect2[3];
	return (r2x >= r1x && r2x + r2w <= r1x + r1w &&
			r2y >= r1y && r2y + r2h <= r1y + r1h);
}

function rectTranslate(rect, dx, dy) {
	rect[0] += dx;
	rect[1] += dy;
	return rect;
}

function rectTranslateCopy(rect, dx, dy) {
	return rectTranslate(rectCopy(rect), dx, dy);
}


function rectCopy(rect) {
	return [rect[0], rect[1], rect[2], rect[3]];
}

// The nowVec is assumed to be inside the rectangle
function collisionResponse(rect, prevVec, nowVec, impactVec, newVelVec) {
	var oldVelVec = vecMinusCopy(nowVec, prevVec);

	var rx1 = rect[0];
	var ry1 = rect[1];
	var rx2 = rx1 + rect[2];
	var ry2 = ry1 + rect[3];

	var xStepLength = oldVelVec[0];
	var yStepLength = Math.abs(oldVelVec[1]);
	
	var vxMultiplier = 1;
	var vyMultiplier = 1;
	
	if (prevVec[0] >= rx2) {
		vxMultiplier = -1;
		impactVec[0] = rx2;
		var xFraction = Math.abs((oldVelVec[0] - impactVec[0]) / oldVelVec[0]);
		impactVec[1] = Math.max(ry1, Math.min(ry2, prevVec[1] + xFraction * oldVelVec[1]));
	} else if (prevVec[0] <= rx1) {
		vxMultiplier = -1;
		impactVec[0] = rx1;
		var xFraction = Math.abs((oldVelVec[0] - impactVec[0]) / oldVelVec[0]);
		impactVec[1] = Math.max(ry1, Math.min(ry2, prevVec[1] + xFraction * oldVelVec[1]));	
	} 
	if (prevVec[1] >= ry2) {
		vyMultiplier = -1;
		impactVec[1] = ry2;
		var yFraction = Math.abs((oldVelVec[1] - impactVec[1]) / oldVelVec[1]);
		impactVec[0] = Math.max(rx1, Math.min(rx2, prevVec[0] + yFraction * oldVelVec[0]));
	} else if (prevVec[1] <= ry1) {
		vyMultiplier = -1;
		impactVec[1] = ry1;
		var yFraction = Math.abs((oldVelVec[1] - impactVec[1]) / oldVelVec[1]);
		impactVec[0] = Math.max(rx1, Math.min(rx2, prevVec[0] + yFraction * oldVelVec[0]));	
	}
	
	
	newVelVec[0] = oldVelVec[0] * vxMultiplier;
	newVelVec[1] = oldVelVec[1] * vyMultiplier;
}



function vecCrossWithZ(vec) {
	return [-vec[1], vec[0]];
}

function vecCrossValue(vec1, vec2) {
	return vec1[0] * vec2[1] - vec1[1] * vec2[0];
}

function vecNormalize(vec) {
	var length = vecLength(vec);
	vec[0] /= length;
	vec[1] /= length;
	return vec;
}

function vecCopy(vec) {
	return [vec[0], vec[1]];
}

function vecNormalizeCopy(vec) {
	return vecNormalize(vecCopy(vec));
}

function vecDistanceBetween(vec1, vec2) {
	return distanceBetween(vec1[0], vec1[1], vec2[0], vec2[1]);
}

function vecDot(vec1, vec2) {
	return vec1[0] * vec2[0] + vec1[1] * vec2[1];
}

function vecMinus(vec1, vec2) {
	vec1[0] -= vec2[0];
	vec1[1] -= vec2[1];
	return vec1;
}

function vecRotate(vec, rad) {
	var x = vec[0];
	var y = vec[1];
	
	var newX = x * Math.cos(rad) - y * Math.sin(rad);
	var newY = x * Math.sin(rad) + y * Math.cos(rad);
	
	vec[0] = newX;
	vec[1] = newY;

	return vec;
}

function vecMult(vec, d) {
	vec[0] *= d;
	vec[1] *= d;
	return vec;
}

function vecMultCopy(vec, d) {
	return vecMult(vecCopy(vec), d);
}

function vecPlus(vec1, vec2) {
	vec1[0] += vec2[0];
	vec1[1] += vec2[1];
	return vec1;
}

function vecMinusCopy(vec1, vec2) {
	return vecMinus(vecCopy(vec1), vec2);
}

function vecPlusCopy(vec1, vec2) {
	return vecPlus(vecCopy(vec1), vec2);
}

function vecLength(vec) {
	return Math.sqrt(vec[0] * vec[0] + vec[1] * vec[1]);
}

function distanceBetween(x1, y1, x2, y2) {
	var diffX = x2 - x1;
	var diffY = y2 - y1;
	
	return Math.sqrt(diffX * diffX + diffY * diffY);
}

function vec2dToString(vec) {
	return "[" + vec[0] + "," + vec[1] + "]";
}


function vec3dToString(vec) {
	return "[" + vec[0] + "," + vec[1] + "," + vec[2] + "]";
}

function vec4dToString(vec) {
	return "[" + vec[0] + "," + vec[1] + "," + vec[2] + "," + vec[3] + "]";
}
