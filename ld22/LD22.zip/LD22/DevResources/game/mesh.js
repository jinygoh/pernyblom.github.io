//

var Mesh = function() {
	this.points = [];
	this.edges = [];
	this.triangles = [];
	this.quads = [];
	this.pointNormals = [];
}

Mesh.prototype.addPoint = function(p) {
	this.points.push(p);
	return this.points.length - 1;
}

Mesh.prototype.addPoints = function() {
	var indices = [];
	for (var i=0; i<arguments.length; i++) {
		indices.push(this.addPoint(arguments[i]));
	}
	return indices;
}

// two element array of point indices
Mesh.prototype.addEdge = function(e) {
	this.edges.push(e);
}

Mesh.prototype.addTriangle = function(t) {
	this.triangles.push(t);
}

Mesh.prototype.addQuad = function(q) {
	this.quads.push(q);
}








