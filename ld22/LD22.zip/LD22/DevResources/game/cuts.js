// cuts
	var test = new js.poly2tri.SweepContext([new js.poly2tri.Point(0, 0), new js.poly2tri.Point(0, 1), new js.poly2tri.Point(1, 1), new js.poly2tri.Point(1, 0)]);
	js.poly2tri.sweep.Triangulate(test);
	
	for (var i=0; i<test.triangles_.length; i++) {
		var tri = test.triangles_[i];
		logit("Triangle " + i + ": ");
		for (var j=0; j<tri.points_.length; j++) {
			var p = tri.points_[j];
			logit(p.x + "," + p.y + " ");
		}
		logit("\n");
	}


			if (Input.keyJustPressed(Input.zKey) || Input.mouseJustPressed) {
			logit("playing sound...\n");
			Sound.play(Sound.SOUND_ID_1);
		}

		
				var lookatMat = new MJS_FLOAT_ARRAY_TYPE(16)
		var perspectiveMat = new MJS_FLOAT_ARRAY_TYPE(16)
		var mvpMat = new MJS_FLOAT_ARRAY_TYPE(16)
		M4x4.makeLookAt([stateCounter * 0.01, stateCounter * 0.02, -100], [0, 0, 0], [0, -1, 0], lookatMat);
		M4x4.makePerspective(60, 1.0, 1, 1000, perspectiveMat);
		M4x4.mul(perspectiveMat, lookatMat, mvpMat);
		
			
		var inputVec = [100 * Math.random() - 50, 200 * Math.random() - 100, 50 * Math.random() - 25];
		var rv = V3.mul4x4(mvpMat, inputVec);
		
		// Mesh test
		var mesh = new Mesh();
		var indices = mesh.addPoints([0, 0, 0], [10, 20, 0], [20, 25, 0], [25, -5, 0]);
		mesh.addQuad(indices);
		indices = mesh.addPoints([0, 0, 25], [10, 20, 25], [20, 25, 25], [25, -5, 25]);
		mesh.addQuad(indices);
		
		// logitRnd("input: " + vec3dToString(inputVec) + " output: " + vec3dToString(rv) + "\n", 0.03);
				
		
		// logit(indices + "\n");
		
		var vpX = 0;
		var vpY = 0;
		var vpW = 600;
		var vpH = 480;
		
		ctx.strokeStyle = "white";
		ctx.beginPath();
		for (var i=0; i<mesh.quads.length; i++) {
			var quad = mesh.quads[i];
			
			for (var j = 0; j<quad.length; j++) {
				var p1 = mesh.points[quad[j]];
				var p2 = mesh.points[quad[(j + 1) % quad.length] ];
				var sp1 = V3.mul4x4(mvpMat, [p1[0], p1[1], p1[2]]);
				var sp2 = V3.mul4x4(mvpMat, [p2[0], p2[1], p2[2]]);

				sp1 = [(sp1[0] + 0.5) * vpW + vpX, (sp1[1] + 0.5) * vpH + vpY];
				sp2 = [(sp2[0] + 0.5) * vpW + vpX, (sp2[1] + 0.5) * vpH + vpY];
				
				// logitRnd(p1 + " " + sp1 + "\n", 0.02);

				ctx.moveTo(sp1[0], sp1[1]);
				ctx.lineTo(sp2[0], sp2[1]);
			}
		}
		ctx.stroke();

		
				ctx.fillRect(0, 0, canvas.width, canvas.height);
		ctx.drawImage(ImageHandler.images.tiles, 32, 0, 64, 32, 32 + stateCounter * 0.1, 100, 32, 32);
		stateCounter++;
		
		
		if (Level.levels.level1) {
			// logitRnd("stuff: " + Level.levels.level1.layers[0].data + "\n", 0.05);
		}
		
		Font.drawString(10, 20, "HELLO MY NAME IS PER!", FontInfos.smallFont);
		
		// if (stateCounter > 600) {
			// Sound.play(Sound.SOUND_ID_1);
			// stateCounter = 0;
		// }
