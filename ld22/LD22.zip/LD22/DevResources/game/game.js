// game

var cameraX = 0;
var cameraY = 0;

var mainMenuButtons = null;
var playButton = null;
var howToPlayButton = null;
var creditsButton = null;
var menuStarParticles = null;

var pauseMenuButtons = null;
var restartButton = null;
var resumeButton = null;
var mainMenuButton = null;


var chargeParticles = [];

function ChargeParticle(obj) {
	this.charge = obj.starCharge;
	this.vx = obj.turnedRight ? 0.01 : -0.01;
	this.vy = 0;
	this.x = obj.x;
	this.y = obj.y;
	this.duration = this.charge * 500;
}

ChargeParticle.prototype.paint = function() {
	ctx.fillStyle = "#ffff00";
	ctx.beginPath();
	ctx.arc(this.x, this.y, this.charge * 4, 0, Math.PI * 2);
	ctx.closePath();
	ctx.fill();
	ctx.fillRect(this.x, this.y, 50, 50);
	// logitRnd("painting particle ", 0.2);
}

ChargeParticle.prototype.step = function() {
	this.x += this.vx;
	this.y += this.vy;
	this.duration--;
}

function stepChargeParticles() {
	for (var i = 0; i<chargeParticles.length; i++) {
		var p = chargeParticles[i];
		if (p != null) {
			p.step();
			if (p.duration <= 0) {
				chargeParticles[i] = null;
				// logit("removing particle\n");
			}
		}
	}
	
	
	
}




function updateCamera() {
	var levelPixelWidth = currentLevel.width * 32;
	var levelPixelHeight = currentLevel.height * 32;

	cameraX = Math.max(0, Math.min(levelPixelWidth - canvas.width, player.x - canvas.width / 2));
	cameraY = Math.max(0, Math.min(levelPixelHeight - canvas.height, player.y - canvas.height / 2));
}


function createPauseMenuStuffIfNecessary() {
	if (pauseMenuButtons == null) {
		pauseMenuButtons = [];
		resumeButton = new Button([50, 50, 100, 20], "RESUME", null);
		resumeButton.paintBackground = false;
		resumeButton.expandWhenMouseOver = true;
		restartButton = new Button([50, 80, 100, 20], "RESTART LEVEL", null);
		restartButton.paintBackground = false;
		restartButton.expandWhenMouseOver = true;
		mainMenuButton = new Button([50, 110, 100, 20], "MAIN MENU", null);
		mainMenuButton.paintBackground = false;
		mainMenuButton.expandWhenMouseOver = true;
		
		pauseMenuButtons.push(resumeButton);
		pauseMenuButtons.push(restartButton);
		pauseMenuButtons.push(mainMenuButton);
	}
}

function createMainMenuStuffIfNecessary() {
	if (mainMenuButtons == null) {
		mainMenuButtons = [];
		playButton = new Button([50, 250, 100, 20], "PLAY", null);
		playButton.paintBackground = false;
		playButton.expandWhenMouseOver = true;
		
		howToPlayButton = new Button([50, 280, 100, 20], "HOW TO PLAY", null);
		howToPlayButton.paintBackground = false;
		howToPlayButton.expandWhenMouseOver = true;

		creditsButton = new Button([50, 310, 100, 20], "CREDITS", null);
		creditsButton.paintBackground = false;
		creditsButton.expandWhenMouseOver = true;
		
		mainMenuButtons.push(playButton);
		mainMenuButtons.push(howToPlayButton);
		mainMenuButtons.push(creditsButton);
	}
	if (menuStarParticles == null) {
		menuStarParticles = [];
		var maxSpeed = 0.15;
		var minSpeed = 0.02;
		var maxW = 0.005;
		var minW = 0.001;
		
		var offset = 100;
		var maxAlphaDelta = 0.001;
		var minAlphaDelta = 0.0002;
		var maxAlpha = 0.8;
		
		for (var i=0; i<10; i++) {
			var x;
			if (Math.random() < 0.5) {
				x = -Math.random() * offset - 64;
			} else {
				x = canvas.width + Math.random() * offset + 64;			
			}
			var y = Math.random() * (canvas.height + offset * 2) - offset;
			var speed = Math.random() * maxSpeed + minSpeed;
			var velAngle = Math.random() * 2.0 * 3.14159;
			
			var alpha = Math.random();
			var alphaDelta = Math.random() * maxAlphaDelta + minAlphaDelta;
			
			var angle = Math.random() * 2.0 * 3.14159;
			var w = maxW * Math.random() * 2 - maxW;
			while (Math.abs(w) < minW) {
				w = maxW * Math.random() * 2 - maxW;
			}
			
			var vx = speed * Math.cos(velAngle);
			var vy = speed * Math.sin(velAngle);
			var scale = 0.2 + Math.random() * 3;
			var p = new MenuStarParticle(x, y, vx, vy, angle, w, scale, alpha, alphaDelta);
			p.maxAlpha = 0.2 + Math.random() * 0.2;
			p.minAlpha = -0.5 * Math.random() - 0.2;
			menuStarParticles.push(p);
		}
	}
}

function stepStarParticles() {	
	for (var i=0; i<menuStarParticles.length; i++) {
		menuStarParticles[i].step();
	}
}

function stepMainMenu() {
	stateCounter++;

	if (stateCounter > 60 && (stateCounter % 41) == 0 && !Sound.isPlaying(Sound.HAPPY_MUSIC_ID)) {
		Sound.play(Sound.HAPPY_MUSIC_ID);
	}
	
	createMainMenuStuffIfNecessary();
	for (var i=0; i<mainMenuButtons.length; i++) {
		mainMenuButtons[i].step();
	}
	
	if (howToPlayButton.clicked) {
		state = HOW_TO_PLAY_MENU;
		stateCounter = 0;
	}
	if (playButton.clicked) {
		state = PLAYING;
		stateCounter = 0;
	}
	if (creditsButton.clicked) {
		state = CREDITS_MENU;
		stateCounter = 0;
	}
	
	stepStarParticles();
}

function stepHowToPlayMenu() {
	stateCounter++;
	
	if (stateCounter > 50 && (Input.mouseDown || Input.anyKeyJustPressed())) {
		state = MAIN_MENU;
		stateCounter = 0;
	}
	
	stepStarParticles();
}

function stepCreditsMenu() {
	stateCounter++;
	
	if (stateCounter > 50 && (Input.mouseDown || Input.anyKeyJustPressed())) {
		state = MAIN_MENU;
		stateCounter = 0;
	}
	
	stepStarParticles();
}

function stepPlaying() {

	if (winning) {
		var completedGame = false;
		var waitTime = 120;
		var waitTime2 = 50;
		if (currentLevel.finalLevel) {
			completedGame = true;
			waitTime = 2000;
			waitTime2 = 120;
		}

		if (stateCounter > waitTime || (stateCounter > waitTime2 && Input.anyKeyJustPressed())) {
			stateCounter = 0;
			winning = false;
			if (completedGame) {
				Level.loadInitialLevel();
				state = MAIN_MENU;
			} else {
				Level.loadNextLevel();
				if (!Sound.isPlaying(Sound.HAPPY_MUSIC_ID)) {
					Sound.play(Sound.HAPPY_MUSIC_ID);
				}
			}
		} else {
			stateCounter++;
		}
		
	} else if (dying) {
		
		if (stateCounter > 120 || (stateCounter > 50 && Input.anyKeyJustPressed())) {
			stateCounter = 0;
			dying = false;
			Level.reloadLevel();
		} else {
			stateCounter++;
		}
		
	} else if (paused) {
		createPauseMenuStuffIfNecessary();
		
		for (var i=0; i<pauseMenuButtons.length; i++) {
			pauseMenuButtons[i].step();
		}
		
		if (resumeButton.clicked || Input.keyJustPressed(Input.escapeKey)) {
			paused = false;
		}
		
		if (restartButton.clicked) {
			stateCounter = 0;
			paused = false;
			Level.reloadLevel();
		}
		
		if (mainMenuButton.clicked) {
			stateCounter = 0;
			Level.reloadLevel();
			state = MAIN_MENU;
			paused = false;
		}
	
	} else {
		stateCounter++;

		updateCamera();

		for (var i=0; i<currentLevel.objectLayers.length; i++) {
			var layer = currentLevel.objectLayers[i];
			for (var j=0; j<layer.objects.length; j++) {
				var o = layer.objects[j];
				o.step();
			}
		}

		// stepChargeParticles();
		
		if (Input.down[Input.escapeKey]) {
			paused = true;
		}
		
		var done = true;
		for (var i=0; i<currentLevel.objectLayers.length; i++) {
			var layer = currentLevel.objectLayers[i];
			for (var j=0; j<layer.objects.length; j++) {
				var o = layer.objects[j];
				if (o != player && !o.dead) {
					done = false;
				}
			}
		}
		
		if (done) {
			winning = true;
			stateCounter = 0;
		}


		
	}
}

function paintMouseCursor() {
	ctx.drawImage(ImageHandler.images.tiles, 0, 32 * 4, 32, 32, Input.mouseX, Input.mouseY, 32, 32);
}

function paintStarParticles() {
	for (var i=0; i<menuStarParticles.length; i++) {
		menuStarParticles[i].paint();
	}
}


function paintMainMenu() {

	var x = 50;
	var y = 10;

	createMainMenuStuffIfNecessary();
	
	paintStarParticles();
	
	var titleImage = ImageHandler.images.title;
	ctx.drawImage(titleImage, x, y);
	
	for (var i=0; i<mainMenuButtons.length; i++) {
		mainMenuButtons[i].paint();
	}
}

var howToPlayTexts = ["*** STORY ***",
					  "YOU ARE ALONE AGAINST A HORDE OF ENEMIES!!!",
					  "",
					  "DONT BE FOOLED BY THE NICE LOOKS OF THE ENEMIES",
					  "THEY ARE FIERCE BEASTS!!!",
					  "",
					  "*** CONTROL ***",
					  "ARROWS, A,S,D,W:  WALK", 
					  "CTRL, X, ENTER:   HIT",
					  "SPACE, C:         CHARGE/RELEASE STAR POWER",
					  "",
					  "*** PICKUPS ***",
					  "PICKUP RED BOTTLES FOR MORE HEALTH",
					  "PICKUP STARS FOR MORE STAR POWER",
					  ];

function paintHowToPlayMenu() {
	createMainMenuStuffIfNecessary();

	
	for (var i=0; i<howToPlayTexts.length; i++) {
		Font.drawString(20, 20 + i * 15, howToPlayTexts[i], FontInfos.smallFont, 1);
	}
	
	paintStarParticles();	
}


var creditTexts = ["THANKS LUDUM DARE FOR SPONSORING THIS CRAZY EVENT", 
					"",
					"SOFTWARE OR OTHER STUFF USED:",
					"* TILED", 
					"* GIMP", 
					"* BLENDER", 
					"* OPEN MPT", 
					"* COOLTEXT.COM", 
					"* BFXR", 
					"* SYNTH1 VST INSTRUMENT", 
					"* FONT 1", 
					"* FONT 2", 
					"* NOTEPAD++"
					];

function paintCreditsMenu() {
	createMainMenuStuffIfNecessary();

	for (var i=0; i<creditTexts.length; i++) {
		Font.drawString(20, 20 + i * 15, creditTexts[i], FontInfos.smallFont, 1);
	}
	
	paintStarParticles();	
}


function paintLevel() {

	var layers = currentLevel.layers;

	var tileLayers = [];
	
	var objectGridYs = [];
	
	var i = 0;
	var j = 0;
	var x = 0;
	var y = 0;

	var tileset = currentLevel.tilesets[0];
	
	var tileWidth = tileset.tilewidth;
	var tileHeight = tileset.tileheight;
	
	var tileCellsX = tileset.imagewidth / tileWidth;
	var tileCellsY = tileset.imageheight / tileHeight;
		
	
	var visibleStartX = Math.floor(cameraX / 32);
	var visibleStartY = Math.floor(cameraY / 32);
	var visibleEndX = Math.ceil((cameraX + canvas.width) / 32);
	var visibleEndY = Math.ceil((cameraY + canvas.height) / 32) + 1;
	
	
	for (y = visibleStartY; y <= visibleEndY; y++) {
		objectGridYs[y] = [];
	}	
	
	
	for (i=0; i<currentLevel.objectLayers.length; i++) {
		var layer = currentLevel.objectLayers[i];
		for (j=0; j<layer.objects.length; j++) {
			var o = layer.objects[j];
			var oGridY = Math.round(o.y / tileHeight);
			if (oGridY >= visibleStartY && oGridY < visibleEndY) {
				objectGridYs[oGridY].push(o);
			} else {
				// logitRnd("Object outside grid? index: " + oGridY + " size: " + currentLevel.height + "\n", 0.1);
			}
		}
	}

	// for (var i = 0; i<chargeParticles.length; i++) {
		// var p = chargeParticles[i];
		// if (p != null) {
			// var oGridY = Math.round(p.y / tileHeight);
			// logit("p: " + p.y);
			
			// logit("checking particle y " + p.y + " gridY: " + oGridY + " vsy: " + visibleStartY + " vey: " + visibleEndY);

			// if (oGridY >= visibleStartY && oGridY < visibleEndY) {
				// objectGridYs[oGridY].push(p);
				// logit("adding particle to grid painter\n");
			// } else {
				// logitRnd("Object outside grid? index: " + oGridY + " size: " + currentLevel.height + "\n", 0.1);
			// }			
		// }
	// }
	

	
	for (y = visibleStartY; y <= visibleEndY; y++) {
		
		for (x = visibleStartX; x <= visibleEndX; x++) {
			for (i = 0; i<currentLevel.tileLayers.length; i++) {
				var layer = currentLevel.tileLayers[i];

				paintLayerCell(layer, x, y, tileCellsX);
				// logitRnd("data: " + data + "\n", 0.01);
			}
		}
		// Paint the objects
		var objArr = objectGridYs[y];
		for (i =0; i<objArr.length; i++) {
			var obj = objArr[i];
			obj.paint();
		}
	}
	
	for (y = visibleStartY; y <= visibleEndY; y++) {
		for (x = visibleStartX; x <= visibleEndX; x++) {
			for (i = 0; i<currentLevel.aboveLayers.length; i++) {
				paintLayerCell(currentLevel.aboveLayers[i], x, y, tileCellsX);
			}
		}
	}

}

function paintPlaying() {

	if (dying) {
		paintLevel();
	
		var dieString = "OOOH NOOOO!!! ";
		var textWidth = dieString.length * 10;
		var tx = (canvas.width - textWidth) / 2;
		var ty = 100;
	
		ctx.fillStyle = "#ffffff";
	
//		logit("drawing string " + textWidth + " " + tx + " " + ty + " " + FontInfos.smallFont + " " + dieString + "\n");
		for (var i=0; i<3; i++) {
			Font.drawString(tx, ty + 15 * i, dieString, FontInfos.smallFont, 1);
		}
		// ctx.globalAlpha = 1.0;
		// Font.drawString(20, 20, dieString, FontInfos.smallFont, 1);
		// ctx.fillRect(tx, ty + 20, textWidth, 10);
		
	} else if (winning) {
		paintLevel();
	
		var completeStrings = ["LEVEL COMPLETE!"];
		
		var completedGame = false;
		if (currentLevel.finalLevel) {
			completeStrings = ["FANTASTIC! YOU WON!!!", 
			"",
			"WELL DONE!"];
			completedGame = true;
		}

		for (var i=0; i<completeStrings.length; i++) {
			var completeString = completeStrings[i];
			var textWidth = completeString.length * 10;
			var tx = (canvas.width - textWidth) / 2;
			var ty = 100 + 14 * i;
			Font.drawString(tx, ty, completeString, FontInfos.smallFont, 1);
		}
	} else if (paused) {
		paintLevel();
		
		createPauseMenuStuffIfNecessary();
		var oldAlpha = ctx.globalAlpha;
		
		ctx.globalAlpha = 0.5;
		
		ctx.fillStyle = "#000000";
		ctx.fillRect(0, 0, canvas.width, canvas.height);

		ctx.globalAlpha = 1.0;
		for (var i=0; i<pauseMenuButtons.length; i++) {
			pauseMenuButtons[i].paint();
		}
		
		ctx.globalAlpha = oldAlpha;
	} else {
		paintLevel();
	}
}


function paintLayerCell(layer, x, y, tileCellsX) {
	
	if (x < 0 || x >= currentLevel.width || y < 0 || y >= currentLevel.height) {
		return;
	}
	var tileIndex = layer.data[x + y * currentLevel.width];
	
	if (tileIndex > 0) {
		var tileX = (tileIndex - 1) % tileCellsX;
		var tileY = Math.floor((tileIndex - 1) / tileCellsX);
		// logitRnd("" + tileIndex + " " + tileX + " " + tileY + "\n", 0.003);
		ctx.drawImage(ImageHandler.images.tiles, tileX * 32, tileY * 32, 32, 32, x * 32 - Math.round(cameraX), y * 32 - Math.round(cameraY), 32, 32);
	}

}


function enemyDie() {
	this.dead = true;
	// Add some kind of explosion here?
}

function playerDie() {
	dying = true;
	stateCounter = 0;
}