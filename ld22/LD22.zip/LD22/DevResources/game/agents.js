// agents

function getObjectRect(obj) {
	return [obj.x - obj.physicalWidth / 2, obj.y - obj.physicalHeight / 2, 
			obj.physicalWidth, obj.physicalHeight];
}

function mirror(imageData) {
	
	for (var i=0; i<imageData.width/2; i++) {
		for (var j=0; j<imageData.height; j++) {
			var index = i * 4 + j * imageData.width * 4;
			var mirrorIndex = (imageData.width - i - 1) * 4 + j * imageData.width * 4;
			for (var k=0; k<4; k++) {
				// Swap
				var temp = imageData.data[index + k];
				imageData.data[index + k] = imageData.data[mirrorIndex + k];
				imageData.data[mirrorIndex + k] = temp;
			}
		}
	}
}


function paintHumanoidSprite(obj) {
	if (obj.dead) {
		return;
	}

	// Takes into consideration the animation state
	if (!obj.spriteImages && obj.image.width != 0) {
		
		obj.spriteImages = [];
		
		// The initial sprite images
		var i = 0;
		for (i=0; i<5; i++) {
			var spriteRect = Level.getSpriteRect(obj, i, 0);
			obj.spriteImages.push(createSubImage(obj.image, spriteRect, null));
		}
		
		// The walk left cycle
		for (i=0; i<5; i++) {
			var spriteRect = Level.getSpriteRect(obj, i, 0);
			obj.spriteImages.push(createSubImage(obj.image, spriteRect, mirror));
		}
		
		// Hit
		var hitSpriteRect = Level.getSpriteRect(obj, 5, 0);
		obj.spriteImages.push(createSubImage(obj.image, hitSpriteRect, null)); // 10
		obj.spriteImages.push(createSubImage(obj.image, hitSpriteRect, mirror)); // 11
	}
	
	
	ctx.drawImage(obj.spriteImages[obj.animationState], 
					0, 0, 
					obj.visualWidth, obj.visualHeight,
					obj.x - obj.visualWidth / 2 - cameraX, obj.y - obj.visualHeight + 16 - cameraY, 
					obj.visualWidth, obj.visualHeight); 
	// ctx.strokeStyle = "#ffffff";
	// ctx.strokeRect(obj.x - obj.physicalWidth / 2 - cameraX, obj.y - obj.physicalHeight / 2 - cameraY, obj.physicalWidth, obj.physicalHeight);
	
	var fractionHealth = obj.health / obj.maxHealth;
	
	var barWidth = Math.min(obj.visualWidth, Math.max(32, obj.visualWidth * (obj.maxHealth / 5)));
	var barRect = [obj.x - barWidth / 2 - cameraX, obj.y - obj.visualHeight / 2 - cameraY - 13, barWidth, 4];
	
	if (fractionHealth < 0.99) { 
		if (fractionHealth > 0.7) {
			ctx.fillStyle = "#00ff00";
		} else if (fractionHealth > 0.3) {
			ctx.fillStyle = "#ffff00";
		} else {
			ctx.fillStyle = "#ff0000";	
		}
		ctx.fillRect(barRect[0], barRect[1], barRect[2] * fractionHealth, barRect[3]);
		ctx.strokeStyle = "#111111";
		ctx.strokeRect(barRect[0], barRect[1], barRect[2], barRect[3]);
	}
	
	if (obj.maxStarPower > 0) {
		var fractionPower = obj.starPower / obj.maxStarPower;
		
		if (fractionPower < 0.99) {
			if (fractionPower > 0.7) {
				ctx.fillStyle = "#ffff00";
			} else if (fractionPower > 0.3) {
				ctx.fillStyle = "#aaaa00";
			} else {
				ctx.fillStyle = "#555500";	
			}
			ctx.fillRect(barRect[0], barRect[1] - 5, barRect[2] * fractionPower, barRect[3]);
			ctx.strokeStyle = "#111111";
			ctx.strokeRect(barRect[0], barRect[1] - 5, barRect[2], barRect[3]);
		}
	}
}


function paintSprite(obj) {
	ctx.drawImage(obj.image, 
					obj.spriteGridX * 32, obj.spriteGridY * 32, 
					obj.visualWidth, obj.visualHeight,
					obj.x - obj.visualWidth / 2 - cameraX, obj.y - obj.visualHeight + 16 - cameraY, 
					obj.visualWidth, obj.visualHeight); 
	ctx.strokeStyle = "#ffffff";
	ctx.strokeRect(obj.x - obj.physicalWidth / 2 - cameraX, obj.y - obj.physicalHeight / 2 - cameraY, obj.physicalWidth, obj.physicalHeight);
}

function paintPlayer() {
	// logitRnd("painting player " + this.x + " " + this.y, 0.02);
	paintHumanoidSprite(this);
	// Font.drawString(this.x - cameraX, this.y + 32 - cameraY, "JAG SKULLE VILJA HA EN GLASS TACK!! 450032 KR BLIR DET", FontInfos.smallFont);
}


function paintKid() {
	// logitRnd("painting kid", 0.01);
	paintHumanoidSprite(this);
}

function paintBully() {
	// logitRnd("painting bully " + this.type, 0.01);
	paintSprite(this);
}

function paintBall() {
	paintSprite(this);
}

function moveObject(obj) {
	var currentRect = getObjectRect(obj);

	var finalVx = obj.vx;
	var finalVy = obj.vy;
	
	// Apply velocity mods
	var removeIndex = -1;
	for (var i=0; i<obj.velocityModifiers.length; i++) {	
		var vmod = obj.velocityModifiers[i];
		vmod.duration--;
		if (vmod.duration < 0) {
			removeIndex = i;
		} else {
			finalVx += vmod.vx;
			finalVy += vmod.vy;
		}
		// logit("finalVx: " + finalVx + "\n");
	}
	if (removeIndex != -1) {
		obj.velocityModifiers.length = 0;
		// obj.velocityModifiers = obj.velocityModifiers.splice(removeIndex, 1);
	}
	
	var wantedRect = rectTranslateCopy(currentRect, finalVx, finalVy);

	if (Level.intersectLevel(currentLevel, wantedRect)) {
		// Intersected, check each direction separately
		wantedRect = rectTranslateCopy(currentRect, finalVx, 0);
		if (Level.intersectLevel(currentLevel, wantedRect)) {
			finalVx = 0;
		}
		wantedRect = rectTranslateCopy(currentRect, 0, finalVy);
		if (Level.intersectLevel(currentLevel, wantedRect)) {
			finalVy = 0;
		}
	}
	
	var objects = currentLevel.objectLayers[0].objects;

	// Get a new rect
	// wantedRect = rectTranslateCopy(currentRect, finalVx, finalVy);

	// for (var i=0; i<objects.length; i++) {
		// var o = objects[i];
		
		// if (!o.dead && !o.idle && obj != o) {
			// if (rectCollide(wantedRect, getObjectRect(o))) {
				// var testRect = rectTranslateCopy(wantedRect, finalVx, 0);
				// if (rectCollide(wantedRect, getObjectRect(o))) {
					// finalVx = 0;
				// }
			// }
		// }
	// }
	
	
	obj.x += finalVx;
	obj.y += finalVy;


	var removeIndex = -1;
	

	
}

function stepHumanoidStar(obj, starWanted) {
	if (obj.charging) {
		if (!starWanted) {
			// Release it
			Sound.play(Sound.RELEASE_ID);
			obj.charging = false;
			obj.health = Math.min(obj.maxHealth, obj.health + obj.starCharge * 0.5);
			// Level.releaseStarCharge(obj);
			obj.starCharge = 0;
		} else {
			// Keep charging 
			var ch = 0.01;
			obj.starPower -= ch;
			if (obj.starPower <= 0) {
				obj.starPower = 0;
			} else {
				obj.starCharge += ch;
			}
		}
	} else {
		if (starWanted) {
			// Start charging
			obj.charging = true;
			Sound.play(Sound.CHARGE_ID);
		} else {
			// Nothing
		}
	}	
}

function stepHumanoidHitting(obj, hitWanted) {
	if (hitWanted) {
		// logit("hit counter: " + obj.hitCounter);
		if (obj.hitCounter > obj.hitPeriod) {
			Sound.play(Sound.TRY_HIT_ID);
			obj.hitCounter = 0;
			obj.hitting = true;
			
			obj.animationState = obj.turnedRight ? 10 : 11;
			var ix = -obj.hitImpulse;
			var s = -1;
			if (obj.turnedRight) {
				ix *= -1;
				s = 1;
			}
			var iy = 0;
			Level.hitImpulse(obj, 
							 {x: obj.x + s * obj.hitImpulseSourceX,
							 y: obj.y + s * obj.hitImpulseSourceY, 
							 impulseX: ix, 
							 impulseY: iy,
							 width: 10,
							 height: 10,
							 duration: 10,
							 damage: obj.hitDamage});
		}
	}
	obj.hitCounter++;
	
	if (obj.hitting) {
		obj.vx = 0;
		obj.vy = 0;
		if (obj.hitCounter > obj.hitPeriod2) {
			obj.animationState = obj.turnedRight ? 0 : 5;
			obj.hitting = false;
			// logit("hitcounter: " + obj.hitCounter + "\n");
		}
	}
	
	if (obj.charging) {
		obj.vx = 0;
		obj.vy = 0;
	}

}

function stepHumanoidMovement(obj, wantedDx, wantedDy) {
	var multiplier = 1.0;
	if (wantedDx != 0 && wantedDy != 0) {
		multiplier = 0.707;
	}
	
	obj.vx = multiplier * wantedDx;
	obj.vy = multiplier * wantedDy;
	
	
	if (wantedDx != 0 || wantedDy != 0) {
		// Moving
		if (obj.animationCounter > 10) {
			obj.animationState++;
			if (wantedDx > 0) {
				obj.turnedRight = true;
				if (obj.animationState > 4) {
					obj.animationState = 1;
				}
			} else if (wantedDx < 0) {
				obj.turnedRight = false;
				if (obj.animationState > 9 || obj.animationState < 6) {
					obj.animationState = 6;
				}			
			} else {
				if (obj.turnedRight) {
					if (obj.animationState > 4) {
						obj.animationState = 1;
					}				
				} else {
					if (obj.animationState > 9 || obj.animationState < 6) {
						obj.animationState = 6;
					}				
				}
			}
			obj.animationCounter = 0;
		} else {
			obj.animationCounter++;
		}
	} else {
		// Other actions change to other states
		if (!obj.hitting && obj.hitCounter > 15) {
			obj.animationState = obj.turnedRight ? 0 : 5;
		}
	}

}

function stepPlayer() {
	
	var wantedDx = 0;
	var wantedDy = 0;
	var speed = 2.0;
	
	if (Input.keyDown(Input.leftKey) || Input.keyDown(Input.aKey)) {
		wantedDx = -speed;
	}
	if (Input.keyDown(Input.rightKey) || Input.keyDown(Input.dKey)) {
		wantedDx = speed;
	}
	if (Input.keyDown(Input.upKey) || Input.keyDown(Input.wKey)) {
		wantedDy = -speed;
	}
	if (Input.keyDown(Input.downKey) || Input.keyDown(Input.sKey)) {
		wantedDy = speed;
	}

	stepHumanoidMovement(this, wantedDx, wantedDy);
	
	var hitWanted = false;
	// if (Input.anyOfTheseKeysDown([Input.ctrlKey, Input.xKey])) {
		// hitWanted = true;
	// }
	if (Input.down[Input.ctrlKey] || Input.down[Input.xKey]) {
		hitWanted = true;
	}
	stepHumanoidHitting(this, hitWanted);
	
	// logitRnd("down: " + Input.down + " player vel: " + this.vx + " " + this.vy + "\n", 0.02);
	
	var starWanted = false;
	if (Input.down[Input.enterKey] || Input.down[Input.cKey]) {
		starWanted = true;
	}
	stepHumanoidStar(this, starWanted);
	
	moveObject(this);

	Level.getPickupAt([this.x-1, this.y-1, 2, 2]);
}

function botBehave(obj) {
	var wDx = 0;
	var wDy = 0;
	var hit = false;
	
	var diffVecLeft = vecMinusCopy([player.x - 20, player.y], [obj.x, obj.y]);
	var diffVecRight = vecMinusCopy([player.x + 20, player.y], [obj.x, obj.y]);

	var distanceToPlayerLeft = vecLength(diffVecLeft);
	var distanceToPlayerRight = vecLength(diffVecRight);
	
	var diffVec = distanceToPlayerLeft < distanceToPlayerRight ? diffVecLeft : diffVecRight;
	var distance = Math.min(distanceToPlayerLeft, distanceToPlayerRight);
	
	// logitRnd("in botBehave\n", 0.3);
	
	if (distance > 0.01) {
		
		var nDiffVec = vecNormalizeCopy(diffVec);
		
		switch (obj.aiMode) {
			case IDLE:
				logitRnd("should not happen that botBehave has mode IDLE\n", 0.01);
				break;
			case PATROLLING:
				if (distance < 400) {
					obj.aiMode = ATTACKING;
				}
				break;
			case ATTACKING:
				if (distance < 15 && diffVec[1] < 8) {
					hit = true;
				} else {
					wDx = nDiffVec[0] * obj.maxSpeed;
					wDy = nDiffVec[1] * obj.maxSpeed;
				}
				break;
		}
	}
	
	var renormalize = false;
	
	var objects = currentLevel.objectLayers[0].objects;
	for (var i=0; i<objects.length; i++) {
		var o = objects[i];
		if (o != obj && o != player) {
			var diffVec = [o.x - obj.x, o.y - obj.y];
			var len = vecLength(diffVec);
			if (len < 25) {
				var nDiffVec = vecNormalizeCopy(diffVec);
				wDx -= nDiffVec[0] * 2.0;
				wDy -= nDiffVec[1] * 2.0;
				renormalize = true;
			}
		}
	}
	
	if (renormalize) {
		var vec = [wDx, wDy];
		if (vecLength(vec) > 0.05) {
			vecNormalize(vec);
			vecMult(vec, obj.maxSpeed);
			wDx = vec[0];
			wDy = vec[1];
		}
		
	}
	
	
	
	return {wantedDx: wDx, wantedDy: wDy, hitWanted: hit};
}


function stepKid() {

	if (this.dead) {
		return;
	}

	var distanceToPlayer = vecDistanceBetween([this.x, this.y], [player.x, player.y]);
	
	if (this.aiMode == IDLE) {
		// Check distance to player
		if (distanceToPlayer < 1200) {
			this.aiMode = PATROLLING;
		} else {
			return;
		}
	} else if (this.aiMode == PATROLLING) {
		// Check if we should go into idle
		if (distanceToPlayer > 1500) {
			this.aiMode = IDLE;
			return;
		}
	}

	// logitRnd("mode: " + this.aiMode + "\n", 0.05);
	
	var botBehaveInfo = null;
	if (this.oldBotBehaveInfo == null || this.counter > this.decisionPeriod) {
		botBehaveInfo = botBehave(this);
		this.counter = 0;
		this.oldBotBehaveInfo = botBehaveInfo;
	} else {
		botBehaveInfo = this.oldBotBehaveInfo;
	}
	this.counter++;
	
	var wantedDx = botBehaveInfo.wantedDx;
	var wantedDy = botBehaveInfo.wantedDy;
	
	stepHumanoidMovement(this, wantedDx, wantedDy);

	var hitWanted = botBehaveInfo.hitWanted;
	stepHumanoidHitting(this, hitWanted);

	moveObject(this);
}

// Remove this :)
function stepBully() {
	moveObject(this);
}

// Remove this :)
function stepBall() {
	moveObject(this);
}


function selectKidActivity(kid) {
	// Only one main activity at a time
	
	// There can also be a secondary activity like harass, assault, coerce, talk
	

	// All get tired of activities of certain types at a different pace
	
	// Persons can get sad if an activity is aborted (such as a ball playing game ends)
	
	// All activities have participants
	
	// Switching activity can be to leave directly, ask someone for a new activity

	// Bullies tend to stay out of normal activities but can coerce other to make them freeze out etc.
	
	// Main objective of the player is to keep the kids and player happy and the bully lonely. 
	// When bully loneliness reaches max, he asks everyone for foregiveness :)
	
	
	
}



