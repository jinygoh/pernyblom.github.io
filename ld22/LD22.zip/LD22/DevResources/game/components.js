// components

function Button(rect, text, image) {
	this.rect = rect;
	this.text = text;
	this.image = image;
	this.mouseOver = false;
	this.pressed = false;
	this.clicked = false;
	this.paintBackground = true;
	this.expandWhenMouseOver = false;
	this.centralizeH = false;
	this.centralizeV = true;
}


Button.prototype.paint = function() {
	var borderStyle = "#3b39ff";

	if (this.mouseOver || this.clicked) {
		borderStyle = "#b8b7ff";
	}
	
	var fillStyle = "#01008c";
	if (this.mouseOver || this.clicked) {
		fillStyle = "#1e1cff";
	}
	
	var x = this.rect[0];
	var y = this.rect[1];
	var w = this.rect[2];
	var h = this.rect[3];
	
	ctx.strokeStyle = borderStyle;
	ctx.fillStyle = fillStyle;
	
	if (this.paintBackground) {
		ctx.fillRect(x, y, w, h);
		ctx.strokeRect(x, y, w, h);
	}
	
	var textWidth = 10 * this.text.length;
	var textHeight = 10;
	
	var scale = 1;
	if (this.expandWhenMouseOver && (this.mouseOver || this.pressed)) {
		scale = 1.5;
	}
	var tx = x;
	var ty = y;
	if (this.centralizeH) {
		tx = x + (w - textWidth * scale) / 2;
	}
	if (this.centralizeV) {
		ty = y + (h - textHeight * scale) / 2;
	}
	Font.drawString(tx, ty, this.text, FontInfos.smallFont, scale);
	
	
}

Button.prototype.step = function() {
	var overBefore = this.mouseOver;
	this.mouseOver = rectContains(this.rect, [Input.mouseX, Input.mouseY]);

	if (this.mouseOver && !overBefore) {
		Sound.play(Sound.BLIP_1_ID);
	}
	
	this.clicked = false;
	if (this.pressed && !Input.mouseDown && this.mouseOver) {
		this.clicked = true;
		Sound.play(Sound.BUTTON_PRESS_1_ID);
	}
	
	this.pressed = Input.mouseDown && this.mouseOver;
	
}